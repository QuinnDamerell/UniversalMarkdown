Username: knowingneurons

General field: Neuroscience

Specific field: Electrophysiology and neurogenetics

Areas of research: biomarkers of neurodevelopmental disorders; complexity and nonlinear dynamics in electrophysiological signals

Education: Third (almost fourth) year neuroscience PhD student

Comments: [1](https://www.reddit.com/r/explainlikeimfive/comments/3igfh9/eli5_why_does_the_mammal_brain_have_more_than_100/cul0wu9), [2](https://www.reddit.com/r/askscience/comments/3ivt47/how_come_we_humans_can_recognize_a_face_from/cukzn20), [3](https://www.reddit.com/r/askscience/comments/3icyzo/is_there_evidence_of_neurons_synaptically/cufd0ze), [4](https://www.reddit.com/r/explainlikeimfive/comments/3hlam3/eli5_does_the_brain_burn_more_calories_doing_hard/cu8ipz7)