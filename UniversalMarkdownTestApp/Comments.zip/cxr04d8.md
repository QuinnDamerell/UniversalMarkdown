Username: masterpym

General Field: Biology

Specific Field: Molecular Biology

Particular Areas of Research Interest: Human Anatomy, Molecular Genetics, and Cellular Biology

Education: MS in Molecular Biology with post-grad work in biochemistry and 6 years experience as a professor of human anatomy and physiology and cellular biology.

Comments: I just joined today!  Hopefully I can help out.