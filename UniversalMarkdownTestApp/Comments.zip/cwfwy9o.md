/u/taciturnbob

A couple of questions... I'm actually doing my MPH at GW right now (first year)! So I would love to know how you transitioned into a PhD at Johns Hopkins. What are your thoughts on the rigorousness of the GW program and how that translates into the career field? I don't have a math/science background (I did my bachelors in , so I'm concerned about how my skills will translate into the field. My end goal I think is to do my PhD and transition into more field-work (but primarily in the US). 

/u/piper 

How did you get into Human Genome Sequencing and genetics? I'm really interested but, as I said before, don't really have the background right now. Is this something you can learn on the job in addition to general training? Likely the answer is no but I'm still wondering. :)

Thanks to you both!!!