I agree, this lends more towards Bio-Biochem-BioMed.

As they say, "your mileage may vary."