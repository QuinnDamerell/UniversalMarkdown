Username: Physics-Trained_Ape

General Field: Physics

Specific Field: Materials Science

Research Area: Theoretical Solid-State Physics

Education: MSc Student

Comments: [1](https://www.reddit.com/r/askscience/comments/3rght2/in_an_ionic_bond_is_the_metal_always_the_cation/cwpxoha), [2](https://www.reddit.com/r/askscience/comments/3rixnc/can_youwhy_cant_you_jump_higher_during_the_day/cwp5rf3), [3](https://www.reddit.com/r/askscience/comments/3qtj1y/what_happens_chemically_when_acid_comes_in/cwiwiab), [4](https://www.reddit.com/r/askscience/comments/3qptas/is_it_possible_to_alloy_a_metal_with_a_molten/cwhfc6q)