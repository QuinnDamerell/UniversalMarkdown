Username: mziff  

General field: Engineering  

Particular areas of research include: Ergonomics and bio-mechanics of the spine, specifically the lumbar region. Motion capture as it relates to the bio-mechanics of sports.  

Education: Master's in Industrial Engineering, specialization in Bio-mechanics. Thesis research presented at the 7th World Bio-mechanics Congress.    

Comments: Unfortunately questions pertaining to the field of bio-mechanics are not common on reddit, so I have not been able to use my knowledge to add to comments so far, but I regularly check /r/AskScience for the day that a question arises!  

Flair already granted in /r/Science.