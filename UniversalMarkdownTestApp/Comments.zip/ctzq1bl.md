Username: /u/AlkalineHume

General field: Chemistry

Specific field: Materials Science

Particular areas of research including historical: Metal-organic frameworks, carbon dioxide capture, gas sensing.

Education: PhD, postdoc, scientist at Lawrence Berkeley Lab (2 yrs), scientist at startup company (1 yr).

Comments: [1](https://www.reddit.com/r/science/comments/3gcfjm/this_new_material_could_capture_greenhouse_gas/ctx35vr), [2](https://www.reddit.com/r/askscience/comments/3giyvo/can_there_be_amorphous_gas/ctythok), [3](https://www.reddit.com/r/askscience/comments/3fw6gy/i_bought_my_car_in_2003_and_it_has_never_ran_out/ctt0gyj), [4](https://www.reddit.com/r/science/comments/3dq515/nanowires_give_solar_fuel_cell_efficiency_a/ct8ygxn)