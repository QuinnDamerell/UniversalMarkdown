The easiest way is to look up publications, you can use WebOfKnowledge to search an academics name and see all their publications. Just be warned that this will list every paper they have their name on, they could be in a list of 20, if they are first author or last author it is generally considered to be better than somewhere in the middle of a long list.  

The number of publications isn't always a good indicator, the things that will be an indicator is the journals they publish in, some like Nature have a bigger impact / H-index and are more presitguous, dependent upon field. This can be seen on the journals page on webofknowledge too.  

  Another factor to consider is the number of times that each paper got cited. Those with a higher citation number will generally have a larger impact.  

Each research group will also have a group website, usually via their institutions website. This will usually have a profile of each academic / member and this can cover their work and who they work with in the case of industrial partnerships. 

  Hope this gives you a few more ideas to go on the hunt!