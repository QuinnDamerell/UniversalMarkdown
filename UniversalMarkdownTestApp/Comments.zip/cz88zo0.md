If this is true then that level of corruption is downright terrifying.

Like your government is literally poisoning its citizens?