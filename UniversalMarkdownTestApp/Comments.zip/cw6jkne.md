username: thisdude415

general field: Engineering

Specific field: Biomedical Engineering

particular areas of research: Biologic drug delivery, vascular biology, tissue engineering

Education: current PhD student. Already flaired at /r/science (permalink to recent comment)

comments:

[1](https://www.reddit.com/r/science/comments/2lcr42/possible_alternative_to_antibiotics_scientists/cltsmk7)

[2](https://www.reddit.com/r/science/comments/2x844y/randomized_doubleblind_placebocontrolled_trial/coxt7iw)

[3](https://www.reddit.com/r/askscience/comments/2xof9k/could_a_low_density_solid_float_in_a_gas/cp22ig8)

[4](https://www.reddit.com/r/askscience/comments/3pi0vz/is_the_strength_of_muscles_proportional_to_their/cw6iq07)
