Username: Greentreevor

General field: Geology

Specific field: VPG (Volcanology, Petrology, Geochemistry)

Research Area: Phreatomagmatics

has flair in /r/science

Education: BS, MS in progress

Comments: [1](https://www.reddit.com/r/askscience/comments/3jfnpi/how_do_we_know_what_gaseous_planets_are_made_down/)[2](https://www.reddit.com/r/askscience/comments/3jcfyb/is_iron_carbonate_or_iron_citrate_generally_iron/)[3](https://www.reddit.com/r/askscience/comments/3jrzp8/how_did_pangaea_formbreak_apart/) and this [4](https://www.reddit.com/r/AskAcademia/comments/3jncjx/how_social_is_your_department/) just discovered this subreddit yesterday so these are all my comments