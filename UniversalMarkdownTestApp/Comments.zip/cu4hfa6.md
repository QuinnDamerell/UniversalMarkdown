Username: NawtAGoodNinja

General Field:  Psychology

Specific field:  Trauma Psychology

Masters research in counseling psychology and clinical psychology, specifically regarding posttraumatic stress disorder.

Education:  Master of Science in Counseling Psychology (in progress) from CACREP accredited program.

Comments: [1](https://www.reddit.com/r/AcademicPsychology/comments/1x2uy9/if_i_wanted_to_start_reading_freud_im_a_layman_ba/cf7m45o), [2](https://www.reddit.com/r/askpsychology/comments/3esbwe/my_so_psychologist_pass_judgement_from_a_single/cthwq05?context=3), [3](https://www.reddit.com/r/askpsychology/comments/2j01l1/what_exactly_is_borderline_personality_disorder/cl7ddv1?context=3), [4](https://www.reddit.com/r/askscience/comments/3h5rfj/can_psychological_disordersissues_be_diagnosed/cu4gwrw?context=3
), [5](https://www.reddit.com/r/askpsychology/comments/3auh1l/does_the_myersbriggs_test_have_any_basis_in/csh6jl0?context=10000)