I don't get this. I've seen a few headlines and haven't really looked in to it much but in the UK the corresponding water providers get checked by third parties. 

If any waste above a certain tolerance goes in to the rivers there are massive fines never mind pollutants going in to the water supply. 