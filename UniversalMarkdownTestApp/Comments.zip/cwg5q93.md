>As the funding environment determines what labs can do, your project will need to fall within the bounds of a supervisor's active grant.

This is my understanding of how this works also.