There are [lab services](http://www.karlabs.com/watertestkit/). They'll ship out sample bottles, you'll collect the samples and ship back the bottles.

There are DIY test kits which you can perform in your own home but those aren't nearly as accurate or comprehensive.