Username: danisnotfunny

General Field: Biology

Specific field: Structural Biology

Particular areas of research include the role of CDK5 inhibitors in various protein expression (ie. Tau, GSK3B). Currently studying structure of Kappa Opioid Receptor via site-directed mutagenesis.


Education: BS Biochemistry, currently working in large pharma lab.

Comments: 
[1,](http://www.reddit.com/r/science/comments/2tu16v/science_ama_series_im_gregory_weiss_uc_irvine/co2fm5z)
[2,](http://www.reddit.com/r/askscience/comments/2log70/how_much_of_its_structure_does_protein_retain/clx85b8?context=3) [3](http://www.reddit.com/r/askscience/comments/2ieflc/i_understand_how_a_gene_is_turned_onoff_by/cl1iuap?context=3)
