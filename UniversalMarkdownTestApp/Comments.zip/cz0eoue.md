Username: iayork

General Field: Biology

Specific Field: Virology, immunology

Research Area: Viral immunity

Education: DVM, MSc, PhD, full-time scientist for nearly 30 years, over 50 publications 

Comments: [1](https://www.reddit.com/r/askscience/comments/41520x/how_fast_or_agile_were_large_animals_such_as/cz0c5bb), [2](https://www.reddit.com/r/AskScienceDiscussion/comments/40u4ww/if_pigs_either_never_existed_or_were_never/cyx84b0), [3](https://www.reddit.com/r/askscience/comments/40m2qj/is_it_possible_for_a_virus_to_not_have_any/cyw73xs), [4](https://www.reddit.com/r/askscience/comments/3ya4px/do_animal_species_other_than_humans_have_cultural/cybxmdx), [5](https://www.reddit.com/r/askscience/comments/3xxm6o/would_it_ever_be_possible_to_clone_or_create/cy9gt2c), [6](https://www.reddit.com/r/askscience/comments/3vjvx4/i_work_with_identical_4_year_old_twins_one_has/cxo5xkm)