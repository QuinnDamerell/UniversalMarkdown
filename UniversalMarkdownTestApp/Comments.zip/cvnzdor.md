Username: Bio_Mat

General Field: Biology

Specific Field: Evolution, Ecology

Research Area: Entomology, Sexual Selection, Morphometrics

Education: M.Sc.

Research: Publication track record

Comments: [1](https://www.reddit.com/r/askscience/comments/3naa7v/does_any_animal_eat_mushrooms_as_its_primary_food/), [2](https://www.reddit.com/r/askscience/comments/3n9gqw/water_on_mars_confirmed_by_spectroscopy/)