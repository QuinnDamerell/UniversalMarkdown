> If I've spent so much of my time being a pretty consistent screw-up, a thousand failed experiments and (what I've been going through lately) a thousand unreturned job applications aren't going to faze me as much.

I feel your pain.