Username: /u/EnApelsin 

General field: Physics

Specific field: Nuclear Physics

Particular areas of research: Experimental Nuclear Astrophysics

Education: Second year PhD student

Comments: [1](https://www.reddit.com/r/askscience/comments/3nctak/where_do_the_elements_come_from/) [2](https://www.reddit.com/r/askscience/comments/2kudz3/how_efficiently_stars_use_their_fuel/) [3](https://www.reddit.com/r/askscience/comments/2kqg31/how_does_the_light_during_daytime_on_other_bodies/) [4](https://www.reddit.com/r/askscience/comments/2kgzqm/why_is_radioactive_decay_measured_in_terms_of/) [5](https://www.reddit.com/r/explainlikeimfive/comments/26uzgu/eli5_quantum_mechanics_superpositions/) 