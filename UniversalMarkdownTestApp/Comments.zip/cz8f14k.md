NJ reporting in - found MetallicA and Iron Maiden in my cup. Used it to make a Black Sabbath w. sugar. 

\m/