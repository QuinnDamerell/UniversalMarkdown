Reverse osmosis home kits remove most heavy metals from water, and only cost a couple of hundred bucks to get started.

The filters cost a bit, but there's an easy way to get them paid for. Save your receipts, so when your municipality eventually releases water data that shows that they've been lying to you for, say, 3 years, you can tell them to reimburse you for the cost of your filters for those years in exchange for your not suing them for 65,000x more than their cost.

The Flint mess convinced my wife and I to install a whole-house RO unit, which is a LOT more expensive. We had the fellow who installed it document everything really well, including noting on the install that it was being put in specifically because we had concerns about our local municipal water source being bad (and it most definitely is).

All that said, any parent whose children have been harmed as a result of lies needs to forget the quality of their water and focus their attention on the quality of baseball bats they're going to use to take care of those responsible.