I've changed your flair to "Molecular Biology | Radiology | MS3" - is that correct, or should MS3 also be removed?

(For reference, it's probably quicker to drop us a mod mail about flair changes, although I doubt you're in a hurry!)