That fucking ruining of the film industry in Michigan still burns me to this day. There was a whole fucking industry of local providers cropping up because of it but OH NO, them's liberal Hollywood Elite Latte-Slurpers! Can't have that! We build cars here! Fuuuuuu.

Avengers was going to be shot in Detroit but then fucking Snyder pulls the tax break out from under the film industry, so it goes to Ohio. Fuckstick. 

We could've had something that generates revenue and truly filters down through all levels in this state, but it didn't serve his political agenda so out the window it goes. Fuck the workers and artists that live here. Fuck. Now I'm pissed off all over again.