I'd say price. A former lab I worked for installed an ICP-MS and it costs a ton to get pure argon to create the plasma, it's really cool to operate but expensive. also, ICP would be more useful for isotopic determination rather than just presence and concentration which is easily attainable in AA with a calibration curve. Moreover, using a graphite furnace with AA can detect in parts per ~~million~~ billion which is where the TLV is as determined by OSHA and NIOSH. I know ICP can do parts per ~~billion~~ trillion but that's excessively more than what the regulation is looking for 

Edit: for clarity

Edit 2: AA using a graphite furnace has a sensitivity in the PPB range while ICP-MS can be sensitive into the PPT range 