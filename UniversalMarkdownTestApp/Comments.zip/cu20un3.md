Username: /u/chemdork123

General Field: Chemistry

Specific Field: Organic Chemistry

Particular areas of research including historical: Organic synthesis, laboratory automation, and formulation science

Education: PhD, Organic Chemistry; (2 yr) Automation Chemist; (4 yr) Formulation Scientist

Comments: [1](https://www.reddit.com/r/askscience/comments/3fwp64/does_boiling_chlorinated_water_release_dangerous/cttlme4), [2](https://www.reddit.com/r/askscience/comments/3fa092/can_a_person_tan_through_sunblocksunscreen/ctn3q1n), [3](https://www.reddit.com/r/askscience/comments/3f7onq/is_there_a_liquid_adhesive_that_remains/ctn11go), [4](https://www.reddit.com/r/askscience/comments/3gjq5z/why_does_table_sugar_allow_for_the_easy_cleanup/ctz6itk), [5](https://www.reddit.com/r/askscience/comments/3g8vpx/how_does_super_critical_co2_attract/ctyen4k), [6](https://www.reddit.com/r/askscience/comments/3gb0q5/if_i_were_to_dissolve_different_molecular_sized/cty38a9)