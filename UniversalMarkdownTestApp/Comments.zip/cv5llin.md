Username: Kvothealar

General field: Mathematics & Physics

Specific field: Mathematical Physics

Areas of Research: 

* Creating Genetic Algorithms for Creation of New Mathematical Techniques, 
* Hardware and Software Development for use in Medical Linear Accelerators, 
* Supersymmetric Quantum Mechanics, 
* Darboux-Crum Transformation

I'm also creating my own mathematics camp in hopes to improve mathematics literacy in my area. 

Education: Final year of Physics Honours + Physics Coop + Mathematics Major, where my last years GPA was a 4.3 (Highest possible at my institution). I am expecting to start a PhD in Mathematical Education next year. I have also passed the CAP Professional Practice Exam and am awaiting my Professional Certification.

Comments: [[1]](https://www.reddit.com/r/thebutton/comments/34fzqy/was_just_watching_presses_whenwtf/cqup20d?context=3) [[2]](https://www.reddit.com/r/askscience/comments/3ho1q3/how_devastating_would_it_be_if_a_pluto_sized/cu96me6?context=3) [[3]](https://www.reddit.com/r/oddlysatisfying/comments/3bt7f6/motion_forever/cspf6l4?context=3) [[4]](https://www.reddit.com/r/todayilearned/comments/3cyltp/til_if_you_write_any_number_in_words_english/ct0etm3?context=3) [[5]](https://www.reddit.com/r/tifu/comments/2ympsq/tifu_by_out_thinking_my_kittens/cpbap1t?context=3)

Posts: [[6 (Click on the link to take you to the Mathematica Stack Exchange)]](https://www.reddit.com/r/Mathematica/comments/3d9sxh/problem_formatting_polynomial_output_link_to/) [[7]](https://www.reddit.com/r/weather/comments/32qxre/hoping_to_learn_about_how_to_read_and_understand/) [[8]](https://www.reddit.com/r/LaTeX/comments/3hbx3y/need_advice_creating_custom_beamer_template/)