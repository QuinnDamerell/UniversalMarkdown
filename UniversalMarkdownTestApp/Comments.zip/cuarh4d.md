**Username:** /u/macksionizer  
**General field:** Chemistry  
**Specific field:** Brewing Science   
**Particular areas of research:**  No substantial research yet completed.  Am currently seeking industry funding to endow a Brewing Science lab at my university.    
**Education:** I hold a BS degree in Chemistry, and am a graduate of one of two IBD-accredited Master Brewer programs in North America.  
**Comments:**   
https://www.reddit.com/r/askscience/comments/2x71m0/is_it_true_that_black_clothing_actually_keeps_you/  

https://www.reddit.com/r/askscience/comments/373yht/whats_the_benefit_of_cornstarch_in_recipes_for/  

https://www.reddit.com/r/askscience/comments/343dee/why_is_the_diameter_of_a_copper_ion_smaller_than/

