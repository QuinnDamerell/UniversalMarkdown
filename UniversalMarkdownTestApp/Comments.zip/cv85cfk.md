Username: smbtuckma

General field: Psychology

Specific field: Social Neuroscience

Particular areas of research: neural mechanisms of social cognition
 
Education: PhD student

Comments: [1](https://www.reddit.com/r/askscience/comments/3ll6o9/what_are_the_neurobiological_effects_of/cv83ivr), [2](https://www.reddit.com/r/askscience/comments/3klvrb/in_what_ways_is_the_brains_of_neglectedabused/cv2641j), [3](https://www.reddit.com/r/TrollXChromosomes/comments/32gjfi/mrw_i_spend_too_much_time_on_reddit/cqbkelp), [4](https://www.reddit.com/r/psychology/comments/3lkp2m/100_social_psychology_departments_ranked_by/cv761m1), [5](https://www.reddit.com/r/Neuropsychology/comments/2ufufr/does_anyone_know_what_my_brain_activity_via_fnirs/cq1hlko), [6](https://www.reddit.com/r/science/comments/3mtp80/selfcontrol_saps_memory_resources_new_research/cvi77sg). I also have flair in /r/science