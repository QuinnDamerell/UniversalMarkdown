I couldn't disagree more. A galactic supernova would be the greatest boon in the history of the field.

Multimessenger detection would tell us so much- gravitational waves via aLIGO tell us about the EoS in unprecedented detail. Neutrino detection has come a long way since 1987 as well. We'd have unparalleled observations of the cooling curve and spectra which could settle the r-process debate. 