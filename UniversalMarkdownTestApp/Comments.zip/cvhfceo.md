Username: fightheheathens

General Field: Chemistry

Specific Field: Organic chemistry/polycyclic hydrocarbons

Particular areas of research: Organic synthesis, anti-aromatic compounds, highly conjugated polycyclic hydrocarbons


Education: 4 years industry (2006-2010) M.S. Chemistry (2012), Ph.D. Synthetic Organic chemistry, highly conjugated polycyclic compounds. (Thesis defense in Nov. 2015!) 

comments: [1](https://www.reddit.com/r/askscience/comments/1sm2di/why_does_sprinkling_salt_on_ice_make_it_melt/cdyzum3), [2](https://www.reddit.com/r/askscience/comments/1vbux5/what_is_the_largest_molecule_known_to_exist_and/ceqwxht)