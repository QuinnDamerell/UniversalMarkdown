**Username:** Apiphilia

**Education:** My BS was in Biology concentration on ecology, evolution, and behavior. I'm now in my last year of a PhD in Ecology. My research focuses on the behavior of honeybees.

**Comment:** Could the "co-evolution" in my flair be changed to just "evolution"? If not can we just remove it entirely? 

I don't have any specific training in co-evolution (two of my example comments when I originally requested flair were about co-evolution), but I have taken multiple courses in evolution and currently TA for an evolution course.