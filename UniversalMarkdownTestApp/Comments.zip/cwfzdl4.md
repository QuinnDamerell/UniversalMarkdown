Thank you all for doing this AMA.

I will soon graduate with a BS in Biology from a small private liberal arts university in Texas. GPA is a 2.8 and major GPA is 2.5. Anybody with experience in post-grad Biology is more than welcome to respond.

Unsolicited attention: /u/elitemeatt /u/pengdrew /u/superhelical 

**Where do I even begin after graduation? How do I get a job with a lab so they can help me pay for graduate school?**

/u/dazosan: So with my crummy GPA, how difficult is the application process for post-grad schools? I really want a career in Biology. I still unsure about which precise field but would love to do labwork. How was your experience in the lab?

/u/Jobediah: Looking at your research in herpetology, how does the field look? Is it competitive or rare? I raise two axolotls and have seen some research working with axolotls I find interesting. Maybe one day herpetology research would be my specialty.

/u/p1percub: Tell me about your experience with training in academia and working for industry. I am unsure about choosing between industry and academia. I'm not confident in my ability to teach biology, and am intimidated by how people describe industry as meaningless, repetitive, and boring. But above all, I would love to work in a lab, ideally in Texas.

/u/taciturnbob: I can relate with your indecision. I cannot choose a specific field of biology from anywhere between microbiology to forensics. What helped you most in making your decision to pursue Public Health?

**If I only have one question answered, I would love to know any good resources for finding labs where I can intern/work in where they can help me pay for graduate school. And how to go about applying for those jobs.**