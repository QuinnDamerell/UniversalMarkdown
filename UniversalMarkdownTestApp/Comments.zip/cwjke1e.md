Username: /u/PHealthy

General field: Public Health

Specific field: Infectious Disease

Particular areas of research: Disease Ecology, Pathogenesis, and Epidemiology

Education: MPH

Comments: [1](https://www.reddit.com/r/askscience/comments/31waab/the_cdc_website_states_that_tuberculosis_tb/cq5n1ph), [2](https://www.reddit.com/r/askscience/comments/30mmu0/if_everyone_was_required_to_stay_at_home_for_2/cpu0cja), [3](https://www.reddit.com/r/askscience/comments/34ixjq/what_makes_stdsstis_special_why_dont_we_have/cqvyvkd)

r/science [flair](https://www.reddit.com/r/science/comments/3qqv9c/global_estimates_of_prevalent_and_incident_herpes/)