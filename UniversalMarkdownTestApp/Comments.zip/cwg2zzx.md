Hmmm, so there are a lot of different paths you can take if you're interested in human sexuality. I'm going to focus on the psychology ones. (These are not mutually exclusive; See Mitch's Clinical Psych Guide for some more on this -- http://www.unc.edu/~mjp1970/Mitch's%20Grad%20School%20Advice.pdf)

1) You can do research in human sexuality, by getting a PhD in Psychology, Human Development, Family Studies, etc

or

2) You can practice therapy:

* marital therapy, by getting a masters in Marriage and Family Therapy.

* sex therapy, by meeting the following requirements: http://www.aasect.org/certification/aasect-requirements-sex-therapist-certification (Note I'm not a 100% sure on this one.)

* general therapy by getting a clinical psychology degree (PhD or PsyD).

It seems to me that the most universal path to being able to either study human sexuality OR practicing therapy is to get a Clinical Psychology PhD. Because then you can either conduct research, which generally requires a PhD OR practice because you can be licensed as a general therapist (and it seems that you can get the sex therapy certificate thingy).

The second part of your question is a bit trickier -- for PhDs you'll need to have an individual advisor who does work at least tangentially related to sexuality. So picking a PhD program should be based on what professor you'd like to work with.


So does that help a bit?