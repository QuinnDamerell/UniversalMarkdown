Username: Pelusteriano

General field: Biology

Specific field: Evolutionary ecology | Population genetics

Particular areas of research include plant-fungi-insect interactions, phylogenetic history of ecological interactions and effect of limiting environments on ecological relationships

Education: BS Biology; first year MSc, my research focuses in effect of plant ontogeny on its defensive strategies against herbivores and pathogens.

Comments: [1](http://www.reddit.com/r/askscience/comments/2p72m8/is_natural_selection_the_only_driving_force_of/cmu3600), [2](http://www.reddit.com/r/askscience/comments/3891j6/is_there_any_type_of_bird_that_has_a_hunting/crtzma4), [3](http://www.reddit.com/r/askscience/comments/2f56hv/why_is_the_secondary_structure_of_a_protein/ck6s4zt), [4](http://www.reddit.com/r/askscience/comments/37ohd7/what_is_theorised_to_have_been_the_first_enzyme/crp9v7b), [5](https://www.reddit.com/r/askscience/comments/2p8d3r/i_guess_i_dont_understand_evolution_it_is_100/cmuzqtu), [6](https://www.reddit.com/r/askscience/comments/2mfo0m/how_do_life_forms_evolve_under_less_than/cm4ttqn),  [7](http://www.reddit.com/r/askscience/comments/2qers0/at_some_point_in_history_common_vegetables_had_to/cn69vmc), [8](http://www.reddit.com/r/askscience/comments/2scf48/how_big_or_small_can_animals_get/cnrn0ry), [9](http://www.reddit.com/r/askscience/comments/2nm73z/why_are_we_humans_smarter_than_any_other_mammal/cmg11n2), [10](http://www.reddit.com/r/askscience/comments/2l3io6/is_their_a_plant_that_can_live_purely_by/clsbjnl)