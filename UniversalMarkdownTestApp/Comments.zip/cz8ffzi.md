If you are concerned, you could have your water tested for heavy metals for a hundred bucks or so.
