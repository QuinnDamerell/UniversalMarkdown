Username: /u/tariban 

General field: Computer Science

Specific field: Machine Learning

Current areas of research: Deep Learning.

Previous areas of research: Neuroinformatics, High Performance Computing.

Education: PhD Student

Comments: [1](https://www.reddit.com/r/askscience/comments/3fakaf/askscience_ama_series_we_are_three_math_experts/ctos3a0), [2](https://www.reddit.com/r/science/comments/3eret9/science_ama_series_i_am_stephen_hawking/ctosqw5), [3](https://www.reddit.com/r/askscience/comments/328039/how_complicated_are_computer_chess_programs_and/cqacnc2?context=3), [4](https://www.reddit.com/r/compsci/comments/25cn8a/how_do_i_implement_a_dsp_algorithm/chfw1iz), [5](https://www.reddit.com/r/technology/comments/1dnlph/intel_i7_4770k_gets_overclocked_to_7ghz_required/c9s82bw)