Username: /u/Providang

General field: Biology

Specific field: Biomechanics, comparative anatomy

Particular areas of research including historical: vertebrate locomotion, muscle performance

Education: MS, PhD, postdoc, currently 2nd year Asst Prof

Comments: Have not commented as much lately, but have flair in /r/science and am a post mod there as well as full mod of /r/Awwducational