Username: /u/isison

General field: Electrical Engineering

Specific field: Nanotechnology, solid state physics

Particular areas of research including historical: Computational nanoelectronics, transistors, and solar cells

Education: PhD completed.

Comments: [https://www.reddit.com/user/isison/](https://www.reddit.com/user/isison/)

Has flair in /r/science