A number of folks have asked about the admissions process and while it is field specific, many are approaching a PhD application like undergrad or med school. In my experience it is very different. You are applying to a person (the PI) and not the school, it is more of a job interview than a school application. I had some notes about where to start that I posted in another response, but thought it would benefit all to post as a top comment:

Consider seriously your research questions, what excites you? What specific things interest you? What things don't? Do you have a project or mechanism you'd like to investigate during your PhD? Do you have species, diseases, or mechanisms you want to specialize in?

Now, take the answers to these questions and consider the following:

 - Remember you are applying to a lab, or will ultimately enter a lab. This lab is run by a person. In my experience, you are applying to a person and not a program. Sure you must 'get in' but in academia, if a PI connects with you and wants you in the lab, they will fight for your admission.

 - Research the literature and find people who are doing the things or interested in the types of questions you want to explore and reach out to them. It can be intimidating yes, but you are building a personal connection with the PI to whom you would like to work with for the next 5-7yrs.

 - Caveat: Say you don't have a specific interest, categorize the kinds of things you'd like to study, and look at departments that have a number of PIs working on the types of things that interest you.

 - Reach out to your current advisors, not just for reference letters, but ask them if they know of labs that are (1) doing the kinds of things that interest you, (2) ones that you would fit well within and (3) are taking grad students. Ask if they would feel comfortable introducing you. Here you can begin to build this personal relationship.

 - Apply for Grad School Grants BEFORE YOU APPLY TO GRAD SCHOOL! Apply for the NSF Graduate Research Fellowship Program, EPA Starr Grant (if your research qualifies), and the NIH Pre-doc Fellowship (I don't recall the name offhand). These funds go with you and are not linked to the school. Coming with funding already secured is a HUGE advantage in admission to a program (now the PI does not have to find funds to pay you).

These were some things I think are really helpful and would be happy to answer any other questions! Remember, a PhD is not entirely about how smart you are, it is about your excitement about research, your tenacity to pursue a project, your willingness to fight, fail and keep going. You ability to DO science, not just know it. These are a major component to your grad school successes, so demonstrate to your potential PIs that you have what it takes. Good luck!