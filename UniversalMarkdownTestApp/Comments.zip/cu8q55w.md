Username: /u/medhp

General field: Physics

Specific field: Health Physics

Area of research/expertise: Medical health physics, nuclear medicine, hospital radiation safety.

Education: MSc. Health Physics, 5 years applied radiation safety at a large medical center

Comments: [1](https://www.reddit.com/r/science/comments/yav4a/scientists_find_mutant_butterflies_exposed_to/c5u20cn), [2](https://www.reddit.com/r/science/comments/yav4a/scientists_find_mutant_butterflies_exposed_to/c5u8pgh), [3](https://www.reddit.com/r/science/comments/1fcujz/nasas_curiosity_rover_has_confirmed_what_everyone/ca9hizj), [4](https://www.reddit.com/r/todayilearned/comments/2g0aef/til_when_the_incident_at_chernobyl_took_place/ckgbv1u), [5](https://www.reddit.com/r/Radiology/comments/3b3r05/does_anyone_know_where_i_can_find_icrp/csjbtcq)