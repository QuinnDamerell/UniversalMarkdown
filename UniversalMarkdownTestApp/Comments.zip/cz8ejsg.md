First of all, PJ, Cher and all the other private citizens helping out are an exemplary example of goodwill and should be applauded for their willingness to help.

Secondly, why the fuck do US citizens have to rely on the kindness of strangers to get help after they were knowingly poisoned by their government?  It's a fucking travesty.
