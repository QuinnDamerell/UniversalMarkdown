Our water comes from one the purest aquifers in the U.S., we're good.  
  
https://en.m.wikipedia.org/wiki/Pine_Barrens_(New_Jersey)