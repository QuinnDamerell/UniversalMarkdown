Cutting the film industry was the dumbest fucking thing in the world. Long term investment and some serious re-evaluation of what incentive can give back for specifically out of state labor would have made Detroit thrive.

It feels so painful seeing friends forced to leave because it's near impossible to keep bread on their tables because all the features and shows are gone. I'm at the point where I'm close to leaving and I don't want too. We had an AMAZING incentive that would make any producer's nether regions wetter than a waterfall. I know it makes mine when I remember it. It was seriously one of the best film incentives in North America.

Obviously there's a LOT more to it and some serious fucking mismanagement between the state goverment, their decisions and ridiculous approvals for certain financial elements and a few private investors.

