Username: /u/Chemastery
General Field: Chemistry
Specific Field: Organic Synthesis
Area of research: Total synthesis, methodology development, bioorganic chemistry peptides and carbohydrates.
Education: PhD. 2012. Four years post-doc experience.
Comments: [1](https://www.reddit.com/r/chemistry/comments/3ekih2/what_solvent_can_dissolve_window_glass_thank_you/ctjsxf2) [2](https://www.reddit.com/r/askscience/comments/3bcte4/most_corrosive_acid_and_base_known/csl23gz) [3] (https://www.reddit.com/r/askscience/comments/39shgr/by_considering_entropy_why_dont_oil_and_water_mix/cscw9y2)

If you need anything else, let me know.