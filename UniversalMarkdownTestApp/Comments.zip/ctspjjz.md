Username: [/u/decaelus](https://www.reddit.com/u/decaelus)  
General field: Earth and Planetary Sciences  
Specific field: Exoplanets  
Particular areas of research including historical: Exoplanet transit photometry, Orbital dynamics  
Education: PhD in Planetary Science, Professional astronomer  
Comments: [1](https://www.reddit.com/r/science/comments/1i3qa9/new_evidence_that_the_fluid_injected_into_empty/cb0um6y), [2](https://www.reddit.com/r/science/comments/18ys1r/moon_origin_theory_may_be_wrong/c8je3zg), [3](https://www.reddit.com/r/explainlikeimfive/comments/1mn5yr/eli5_how_we_can_know_so_much_about_other_planets/ccau0aq), [4](https://www.reddit.com/r/askscience/comments/27vi58/why_do_astrobiologists_set_requirements_for_life/ci4sylc)