/u/taciturnbob

What kind of PhD are you pursuing?  I have an undergraduate degree in biological engineering and have been looking into getting a Masters or PhD in biomedical engineering.  However, I have a real passion for Public Health, so I have also thought about a MPH.  Your "circuitous route," as you called it, is very interesting to me.  What kind of work are you planning on getting into after you finish your PhD?  Is there any advice that you can give to someone who want to apply to public health programs in the future?  What kinds of things can I do now that will make me a more competitive applicant?

Thanks for the AMA!