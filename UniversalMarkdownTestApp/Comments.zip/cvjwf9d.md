Username: /u/NiceSasquatch

General field: Physics

Specific field: Atmospheric

Education: PhD 

Comments: 
[0](https://www.reddit.com/r/askscience/comments/3n249w/does_the_top_of_the_burj_khalifa_move_faster_then/cvl3vk7),
[1](https://www.reddit.com/r/askscience/comments/2zzer7/does_the_hemisphere_that_you_are_in_affect_which/cporakl), [2](https://www.reddit.com/r/askscience/comments/33l6e5/what_is_the_environmental_and_long_term_climate/cqma7ad), [3](https://www.reddit.com/r/askscience/comments/2xazeh/whats_the_mass_of_a_particle_in_a_perfect_space/coynmwz)

