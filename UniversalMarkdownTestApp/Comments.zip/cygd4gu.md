Username: /u/oolongtea1369


General field: Chemistry


Specific field: Drug Discovery, focused on the organic synthesis part


Education: MRes graduate (MPhil eqv.)

Comments: [1](https://www.reddit.com/r/askscience/comments/1wggdh/is_is_possible_for_an_acid_to_be_as_corrosive_as/cf1q5fk), [2](https://www.reddit.com/r/chemistry/comments/3a3ecj/a_question_about_sulfonamide_hydrolysis/cs90vyr?context=3), [3](https://www.reddit.com/r/chemistry/comments/3avm7f/column_help/csgknci), [4](https://www.reddit.com/r/chemistry/comments/3dm1bk/need_help_in_converting_a_carboxylic_acid_to_an/ct6ik4m)