Username: /u/brisingr0

General field: Neuroscience

Particular areas of research: Episodic-like memory, systems neuroscience

Education: 2nd year PhD student 

Comments: [1](https://www.reddit.com/r/LifeProTips/comments/32jw2s/lpt_brush_your_teeth_with_your_opposite_hand_once/cqbx7ug) [2](https://www.reddit.com/r/LifeProTips/comments/32jw2s/lpt_brush_your_teeth_with_your_opposite_hand_once/cqbx7ug) [3](https://www.reddit.com/r/science/comments/33jcbb/mixed_lactate_and_caffeine_compound_increases/cqluv92) [4](https://www.reddit.com/r/neuroscience/comments/3ahtld/im_scared_to_get_a_phd_but_i_want_to_devote_my/csctsdl) 

Posts: [1](https://www.reddit.com/r/psychology/comments/3baqn4/a_neuroscientists_persepctive_on_disney_pixars/) [2](https://www.reddit.com/r/philosophy/comments/3jkk3l/the_questions_enchroma_glasses_answer_and_raise/) 

Edit: Also, BA with Honors in Neuroscience and Human physiology 