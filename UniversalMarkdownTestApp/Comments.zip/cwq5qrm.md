Username: dreasdif118

General Field: Social Science

Specific Field: Political Science

Particular Area of Research: US Political Parties, Modern American Political Ideologies, Electoral Politics

Education: BA in Political Science, working towards MA in American Politics 

Comments: There have been very few political science questions and I have been sort of busy with school the last few weeks.
