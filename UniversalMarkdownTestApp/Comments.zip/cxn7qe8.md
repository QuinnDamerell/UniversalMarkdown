Username: [/u/Sheldahl](https://www.reddit.com/user/sheldahl/)

general field: Medicine

Specific field: Pharmacology

particular Areas of research: neuroendocrinology

Education: Ph.D., Pharmacology

Comments: [1](https://www.reddit.com/r/askscience/comments/3s6ug3/when_i_get_a_cold_how_much_of_the_symptomsmisery/), [2](https://www.reddit.com/r/askscience/comments/3spfpi/endocrinology_why_do_some_steroid_hormones_have/), [3](https://www.reddit.com/r/askscience/comments/3tgmn8/how_random_are_mutations/)

Have flair in [/r/science](https://www.reddit.com/r/science)