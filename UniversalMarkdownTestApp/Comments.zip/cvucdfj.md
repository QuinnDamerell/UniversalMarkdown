Username: /u/Angela_Landrigan

General field: Biology

Specific field: Immunology

Particular areas of research including historical: Cancer immunotherapy, T cell signaling

Education: Ph.D. and postdoctoral fellowship completed

Comments: [1](https://www.reddit.com/r/askscience/comments/3np57q/are_new_viruses_spontaneously_mutated_in_one/), [2](https://www.reddit.com/r/askscience/comments/3o4dlr/why_do_we_get_sore_the_day_after_strenuous/), [3](https://www.reddit.com/r/askscience/comments/3n1klp/our_immune_system_can_destroy_foreign_cancer/). More evidence [here](http://angelalandrigan.com/2015/10/09/cancer-and-the-immune-system-illustrated/).