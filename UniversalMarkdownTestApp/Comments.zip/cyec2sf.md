Username: /u/FrijjFiji

General field: Mathematics

Specific field: Logic/Category Theory

Particular areas of research including historical: Natural language through categorical logic

Education: PhD student

Comments: [1](https://www.reddit.com/r/math/comments/3ucrz5/why_is_russels_paradox_such_a_problem/cxe8b7k) [2](https://www.reddit.com/r/math/comments/3c2nto/should_mathematics_have_a_unifying_theory/csruw65) [3](https://www.reddit.com/r/math/comments/3y9skh/draw_me_some_math/cyc1wfy) [4](https://www.reddit.com/r/math/comments/3y5an9/why_isnt_the_axiom_of_choice_a_theorem_it_seems/cyebcu9)