Hi there! Thanks for doing this AMA! 

I'm just about to turn in my application for the California State system (CSU), and one of the steps includes statement of purpose. I know why I want to pursue my graduate degree, so I'll have no problem writing about that, but they gave NO indication of how long this statement should be. My Master's program did, but the CSU system did not. Any recommendations on how long of a statement that should be? 
Thanks!!!