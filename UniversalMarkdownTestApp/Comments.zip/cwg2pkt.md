I have a question for /u/AsAChemicalEngineer. 

I assume you did one of your undergrad degrees in ChemE. What made you switch to high-energy physics? Also, I'm curious as to how you ended up at your current university and what it entailed to join in such a non-traditional way (in the middle of the term and probably out of the normal admission cycle). I am not planning on doing this, but I'd like to know, if you have a moment. 
