This is excellent; the donation from Pearl Jam, their record label, and TicketMaster is a great way to raise awareness to the contamination of Flint's drinking water. According to the EPA, the state and local governments havent come close to doing enough about all the lead in the water system:

>In an emergency administrative order, the Environmental Protection Agency slammed the city of Flint, the Michigan Department of Environmental Quality and the State of Michigan, saying they are all responsible for the lead contamination in the city's water.

>Their responses to the crisis, the EPA said, were "inadequate to protect public health."

That's putting it lightly. Lead in the water is kind of a big deal, the Romans taught us that. Additionally, the EPA itself is also complicit in some ways. Accordingly, they have announced they will be making internal changes in response to this crisis:

>U.S. Rep. Jason Chaffetz, the chairman of the House Oversight Committee, called Hedman's resignation "way overdue."

>"EPA is rife with incompetence and Region 5 [which Hedman was in charge of] is no exception," Chaffetz said in a statement. "One resignation will not change the top to bottom scrubbing EPA needs, but it is a step in the right direction."

[CNN](http://www.cnn.com/2016/01/22/health/flint-water-crisis/)