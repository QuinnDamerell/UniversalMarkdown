/u/theratwhowouldbeking ,
/u/quant_liz_lemon 
or really anyone who could pitch in: 

I'm currently an undergrad student (psychology major, third year) and i'm having a really tough time defining which area of study i want to go into after i get out, i'm getting close to the point where i feel need to define what my time investments should go into, and i know some of the questions here have been a little more complex than this but.. 

When exactly did you figure out the direction you wanted to go after graduation? Did you just have to pick an area and go with it, or did a specific area always stand out for you?