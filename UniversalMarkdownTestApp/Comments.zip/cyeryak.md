Username: /u/absolutezero273    
General field: Biology    
Specific field: Reproduction and fertilization in mammals    
Particular areas of research including historical: Sperm-egg interactions, fertilization, gametogenesis, embryogenesis.    
Education: Very recent PhD graduate!.    
Comments: [1](https://www.reddit.com/r/askscience/comments/3yl6he/how_is_biological_data_stored_in_dna/cyeruhm)    

Recently new to reddit and enjoying my time so far :)  I know all about "conception" and the creation of life.  Pretty neat stuff.