It's still a shithole.

Graduated in 2010. They can't fit all of the kids in the highschool building so they bought a strip mall a mile down the road, stripped it out, and turned it into classrooms. Seniors spend half the day there.

... Never thought I'd get to vent about that on Reddit.