> Q2. How is the job market these days?

Not a psychologist, but I'll reply anyway since this is really an axe I have to grind.

I have a PhD doing a thing that is very industrially relevant to areas of active R&D. I did so at a top 20 university. My thesis advisor is famous in academic circles.

I did on-site interviews with many companies, all of whom declined to make me offers, because of what I call the "Beauty Pageant" method of hiring that pervades industry. They want exactly the right candidate, who already has experience doing the thing they want to do, and they'll be damned if they'll pay you the market wage to do it.

Airgas (a major supplier of industrial gasses) got a hold of my resume and offered me $19,000 a year as a contract employee knowing that I had a PhD! They were looking to hire a PhD at that wage! I made more as a grad student!

The job market sucks.