Completely agree. In genetics there are few reasons to bother with a masters: 

1) you really aren't sure you want to do a PhD- even then I would encourage students to apply for PhD and leave early (they usually give you a masters degree if you have completed two or more years of your PhD program), because nearly all good PhD programs are financially supported (cost the student nothing, and often give the student a stipend to live on) while almost all masters programs are very expensive 

2) you want to get a master's in something very different but helpful to your PhD- like if you want to go into neuro imaging and so you get a masters in CS or you want to go into epidemiology so you get a masters in statistics, in these cases the masters study complements your PhD, makes you a better scientist, and isn't redundant with your PhD work 

3) you are REALLY sure you don't want to do a PhD- if you know your career goal and it doesn't require a doctorate, it may make more sense financially to pay for a 2 year masters degree and get working rather than get paid a small stipend for a 5-7 year doctorate.

* this advice is fairly specific to molecular biology and computation biology fields at universities in the US