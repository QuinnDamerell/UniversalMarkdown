> For those of you who have significantly shifted focus between degrees; 

I switched from Economics to Psychology. I ended up getting majors in both (and a very expensive fifth year of college to boot).

> how difficult was it for you to switch gears so many times, was it a challenge to 'catch' up in your new fields, 

I'm still catching up. My substantive foundation in psychology is a bit shakey in areas. I've been trying to round out my background knowledge by joining and contributing to the Psychology Wikiproject. Forces me to do some reading.


> how often do you draw on your varied backgrounds for an interdisciplinary approach, 

All the time. I cite economics pages, collaborate with economists, and drawn on many of the economic foundations for my work.

> and how do others within your field/program perceive your mixed background?

Most of them dig it. If anything it gives me more stats street cred. Although every once in a while I'll use economics terminology instead of psych terminology -- then I get raised eyebrows until I translate what I said into something comprehensible.

> Bonus question; would it be frowned upon to pursue a PhD at the same institution you get your MSc but in a somewhat related yet different field in a different program i.e., would it look bad?

No.

Most folks (in my field) get their Master's along the way while working on their PhD. Getting your undergrad degree from the same institution as your PhD is a little more sketchy.