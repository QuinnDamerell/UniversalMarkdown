Username: edaciouse

General Field: Psychology

Specific Field: Social Cognition, Cognitive Neuroscience, Evolutionary Psychology

Research Area: Decision Making, Emotional Sensitivity

Education: 2nd year of Ph.D work

Comments: 
https://www.reddit.com/r/science/comments/3vbjjh/people_less_honest_about_their_work_if_they/

https://www.reddit.com/r/askscience/comments/3vbcqs/it_is_a_better_strategy_to_attempt_to_appeal_to/

Flair in r/science: grad student - social cognition|evolutionary psychology