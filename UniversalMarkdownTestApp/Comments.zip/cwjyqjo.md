Username: /u/Golden-Death

General field: Biology

Specific field: Molecular Biology

Particular areas of research including historical: Cell Signaling & Migration

Education: Ph.D. Candidate

Comments: [1](https://www.reddit.com/r/worldnews/comments/33j731/chinese_scientists_just_admitted_to_tweaking_the/cqlpb13), [2](https://www.reddit.com/r/todayilearned/comments/35he45/til_that_scientists_kept_a_species_of_fruit_fly/cr4lyd8), [3](https://www.reddit.com/r/WTF/comments/3av8ls/removing_some_artherosclerotic_plaque/csgn01p), [4](https://www.reddit.com/r/EverythingScience/comments/3jlhqf/carbonated_drinks_linked_to_cardiac_arrest_study/cuqi56j) (also a [/r/science moderator](https://www.reddit.com/r/science/about/moderators))