1)What is the one thing you wished you knew/did in your undergraduate years?
2)What university has the top molecular biology program in the world? Also, UK vs US programs?
3)What are books you would recommend to someone (to learn the basics and to get a general gist) who is planning on doing research/a PhD in the life sciences? (about everything from grants to research methods)
4)Bs>Ms>PhD or Bs>PhD?
5)How do you take advantage of the time you have in your 4 year undergraduate degree program?
6)How long is too long when it comes to getting a PhD? What is the ideal? 4 years? 7?
7)How do you cope with the stress that an academic life necessarily entails? How many hours of sleep do you get on busy days?
8)What should I know about academic fraud?
9)Is post-doc mandatory? Would I be much worst off without doing post-doc?
10)Too many PhDs, too few jobs. agree/disagree?
11)Double major vs Bs-Ms program?
12)In your opinion, which education system prepares students best for research? (UK/US; undergraduate/graduate)