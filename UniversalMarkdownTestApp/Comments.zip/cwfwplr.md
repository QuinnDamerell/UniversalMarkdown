Wow! This is great. Thanks to everyone who put this together or is participating. My questions are for everyone/anyone.
 
What do you wish you did in undergrad to better prepare for going to grad school?
 
What is the difference between your undergrad and graduate social life? 
 
What can I (as an undergrad RA) do to make my grad student's life easier? (we're in a psych lab but I'd be happy to hear anyone's answer!)