I'm sure I'm too late to the party, but I graduated in 2012 and work for a DNA production company. I'd like to get back into academics so I could get my Masters in Anatomy. 

The hardest part for me, I think, is that I never really had long standing/long lasting relationships with any of my professors, and I don't know how to go about getting good referrals for my grad school application.

Any tips or pieces of advice that might be helpful?