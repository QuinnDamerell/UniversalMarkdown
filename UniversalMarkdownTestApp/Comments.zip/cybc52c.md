short answer: we don't know. 
When Maxwell postulated his equations for electromagnetism everybody said: "well that's nice Max, but what can we do with this?"

Now we start to understand stuff on a deeper level, which is very cool. But nobody knows what the use is of these advancements at the most elementary level.


On the other hand: While researching these things and developping machines like the LHC, major advances have been made that can be used in radiotherapy, semiconducter magnets, and even the internet (the www was invented at CERN as some side-project)