Username: /u/Fenzik (flaired in /r/Science)

General field: Physics

Specific field: Theoretical High Energy Physics

Particular areas of research: String Theory, Quantum Field Theory

Education: Master's Student

Comments: [1](https://www.reddit.com/r/AskScienceDiscussion/comments/3wwz3c/cosmology_could_a_white_hole_be_continually/cxzmw3v?context=3), [2](https://www.reddit.com/r/AskScienceDiscussion/comments/3w86uv/speculation_is_it_possible_that_the_progression/cxunkci?context=3), [3](https://www.reddit.com/r/bestof/comments/3qwkav/redditor_tries_to_help_a_devoutly_religious/cwjby1b), [4](https://www.reddit.com/r/cheatatmathhomework/comments/3o0jj1/physics_question_forces/cvsxuvq?context=3) (and ensuing discussions).