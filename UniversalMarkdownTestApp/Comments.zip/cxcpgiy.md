Username: /u/aurochseye

General field: Medicine

Specific field: Veterinary Medicine

Particular areas of research including: Epidemiology, public health, small holder livestock

Education: DVM, MPH

Comments: [1](https://www.reddit.com/r/askscience/comments/3u4moo/can_bacteria_become_antiseptic_resistant_like/cxcjnk7) [2](https://www.reddit.com/r/explainlikeimfive/comments/3tpbkb/eli5_how_does_the_ames_test_work_and_why_does_it/cx9jvop) [3](https://www.reddit.com/r/askscience/comments/3tfrw2/overuse_of_antibiotics_in_farm_animals_does_it/cx9ctte) [4](https://www.reddit.com/r/askscience/comments/3tbe3f/how_is_puberty_different_in_nonhuman_animals/cx703gq)

*Edit* Also have /r/science flair!