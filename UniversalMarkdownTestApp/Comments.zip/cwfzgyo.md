Don't forget, that while frowned upon, most PhD programs award a Masters after you finish your qualifiers, and you can choose to leave with a Masters if it's not working out.

This is generally frowned upon, and in some respects can hurt your career prospects, but it's an option.