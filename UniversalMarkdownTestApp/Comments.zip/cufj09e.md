Username /u/apr400

General field: Physics

Specific field: Nanofabrication

Particular areas of research including historical: Lithography, Etching, Surface Science, Nanoscale Physics, Surface Chemistry.

Education: PhD Physics. Research active university academic since 1999

Comments: [1](https://www.reddit.com/r/askscience/comments/33jwnp/would_it_be_possible_to_adjust_your_computers_or/cqlus79), [2](https://www.reddit.com/r/askscience/comments/2bkyy1/scientists_says_sea_levels_could_rise_7_meters_if/cj6efht), [3](https://www.reddit.com/r/askscience/comments/1v9tur/i_saw_earlier_in_rtodayilearned_that_theres_a/ceq6xli), [4](https://www.reddit.com/r/askscience/comments/2jeo73/are_there_any_actual_images_of_atoms_is_it/clbargy), [5](https://www.reddit.com/r/askscience/comments/2jhkbu/can_we_see_multiple_places_in_the_universe_that/clc0bjj), [6](https://www.reddit.com/r/askscience/comments/2iuk3a/the_other_day_i_took_some_10_year_old_students_of/cl5pk2i)