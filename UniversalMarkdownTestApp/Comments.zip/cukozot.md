Username: /u/askLubich 

General field: Physics

Specific field: Statistical Physics

Particular areas of research including historical: Computational biophysics, MD Simulation

Education: Master student

Submissions: [1](https://www.reddit.com/r/educationalgifs/comments/3hlncu/induction_heating_is_used_for_welding_and_cooking/), [2](https://www.reddit.com/r/physicsgifs/comments/3gw9is/simulation_of_lipid_bilayer_selfassembly_better/), [3](https://www.reddit.com/r/educationalgifs/comments/3gnsxq/muscle_contraction_an_filament_level_made_visible/), [4](https://www.reddit.com/r/dataisbeautiful/comments/3dko1y/posting_imgur_albums_32_of_viewers_leave_after/), [5](https://www.reddit.com/r/physicsgifs/comments/3abkds/the_beauty_of_the_lorenz_system/)

Comments: [1](https://www.reddit.com/r/educationalgifs/comments/3hlncu/induction_heating_is_used_for_welding_and_cooking/cu8i12p), [2](https://www.reddit.com/r/physicsgifs/comments/3gw9is/simulation_of_lipid_bilayer_selfassembly_better/cu217d1), [3](https://www.reddit.com/r/educationalgifs/comments/3gnsxq/muscle_contraction_an_filament_level_made_visible/ctzut9y), [4](https://www.reddit.com/r/physicsgifs/comments/3efsvn/actin_filaments_moving_on_a_myosincoated_surface/cthmtqz), [5](https://www.reddit.com/r/physicsgifs/comments/3abkds/the_beauty_of_the_lorenz_system/csc92lz), [6](https://www.reddit.com/r/physicsgifs/comments/3abkds/the_beauty_of_the_lorenz_system/csb81pl), [7](https://www.reddit.com/r/askscience/comments/2wt7gq/when_an_electron_and_an_antielectron_collide_they/couyaef)

I am also have a /r/science flair.