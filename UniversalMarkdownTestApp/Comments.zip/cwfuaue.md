I'll chime in and say that while I know that this is common in ecology, it's not common for molecular biologists in the US (India and whatnot is a different story).

There are not nearly as many masters granting molecular biology programs, and most of them are at smaller or private schools. Getting a masters in molecular biology from a tier 1 research school generally indicates you left a PhD program after finishing quals.

Instead I would recommend that aspiring 'bench biologists' tech for a couple of years in a research lab. Sure you won't get a degree, however you also won't have to pay for a masters.