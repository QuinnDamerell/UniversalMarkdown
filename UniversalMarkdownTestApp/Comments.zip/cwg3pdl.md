I struggled a lot with my research interests. I started out wanting to do clinical, like everyone else. Then I wanted to do social because I was interested in this marriage study. Then I wanted to do personality because personality was a good predictor. Then I wanted to do Quant because I was good at it and the job market was pretty. 

What I did to help me out was make a list of all the research projects I had done for my classes. And see what the general themes were. It helped me a lot to get a sense of what I actually had already done. 

It turned out that I had consistently been interested in families, marriage, and the cold war. So I looked for faculty who did quanty psychology work using family data. 

But, I guess I just picked an area and went with it because Quantitative Psychology stood out as the most universal.