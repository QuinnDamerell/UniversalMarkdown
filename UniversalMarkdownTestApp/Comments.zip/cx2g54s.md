username: mrfollicle

general field: computing

specific field: systems and network engineering technology

particular areas of research: technology education, networking, cyber security, cyberphysical laboratories

education: MS

comments: [1](https://www.reddit.com/r/askscience/comments/3sqqb4/why_do_games_on_cellphonestablets_drain_the/cx2ftjz), [2](https://www.reddit.com/r/askscience/comments/3spvw5/how_does_a_network_differentiate_between/cx2fkxn), [3](https://www.reddit.com/r/askscience/comments/3su6oa/what_optimization_algorithm_does_disk/cx2f6rz), [4](https://www.reddit.com/r/askscience/comments/3rx5ne/if_gold_was_used_in_motherboards_for_conductivity/cwubfx7)

already have /r/science flair 