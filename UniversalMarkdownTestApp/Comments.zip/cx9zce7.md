Username: **LegendOfMax**

General field: **Medicine** 

Specific field: **Veterinary medicine**

Particular areas of research: **Companion animal medicine**

Education: **Natural Resources, Ecology and Management - B.S.**

**Doctor of Veterinary Medicine - Candidate: 2nd year of 4**

Comment: [Only one, currently.](https://www.reddit.com/r/askscience/comments/3twjlg/is_there_a_relationship_between_miosismydrasis/cx9yl2f)