> way to specialized for an industry job

I don't think that problem exists.  A PhD is an official stamp that the holder can learn complex new information, and then apply that information in novel ways to solve hard problems.  While your PhD friend may have a difficult time finding an industry job doing what she did in academia, it shouldn't be as hard to find an industry job that leverages her general talents & capabilities.

Edit: Forgot to mention that I am talking about the USA.  Job markets for technical skills may vary internationally.