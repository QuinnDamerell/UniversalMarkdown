Username: theduckparticle

General field: Theoretical physics

Specific field: Quantum information/statistical physics/quantum field theory

Research area: Tensor networks

Education: MSc in theoretical physics; currently on 2nd year of physics PhD

Comments: [1](https://www.reddit.com/r/askscience/comments/2zbcik/if_we_could_create_a_solar_panel_that_works_with/cphftmz) [2](https://www.reddit.com/r/askscience/comments/2znso5/why_does_schrodingers_time_dependent_equation/cpkogua) [3](https://www.reddit.com/r/askscience/comments/3i8u99/is_there_a_way_to_harness_gravity_for_energy_if/cuefxzn) [4](https://www.reddit.com/r/askscience/comments/31laws/can_anyone_explain_the_three_interactions/cq2xpwk) [5](https://www.reddit.com/r/askscience/comments/2yqjt8/does_entropy_ever_actually_decrease_globally_for/cpc1n2z?context=3) [6](https://www.reddit.com/r/askscience/comments/313wnr/is_it_accurate_to_say_that_a_magnetic_field_is/cpycqaz)