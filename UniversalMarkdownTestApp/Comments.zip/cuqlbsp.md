Username: thevolodymyr  
General field: Physics  
Specific field: Astrophysics  
Particular areas of research including historical: Gamma-ray bursts, Cosmic rays, Hard X-ray and Gamma-ray instrumentation  
Education: PhD done in 2012.   
Comments: [1] (https://www.reddit.com/r/askscience/comments/3jg6g7/can_a_neutron_star_turn_into_a_black_hole/), [2](https://www.reddit.com/r/askscience/comments/3jjcqd/if_black_holes_slowely_lose_mass_due_to_hawking/)  