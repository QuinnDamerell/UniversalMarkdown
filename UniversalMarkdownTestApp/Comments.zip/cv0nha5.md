Username: JACK925198 
General Field: Chemistry
Specific field: Spectroscopy-Artificial Photosynthesis and MAS NMR
Education: Postdoc 4 years , Ph. D.
Comments:I just found this subreddit a few days ago, and am relatively new to reddit in general