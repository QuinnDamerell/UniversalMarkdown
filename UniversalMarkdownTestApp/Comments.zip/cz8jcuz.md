>it's post office is open

Pretty sad when that's the only thing they can come up with say about a place. Oh, this state. Now I'm even more sad I live here :(