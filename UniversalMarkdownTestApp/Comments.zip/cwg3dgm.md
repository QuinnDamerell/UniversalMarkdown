I graduated with a BS in neuroscience and am looking to get into a PhD in the same discipline. I worked as a research assistant for a chem professor for 6 months and did an independent project for my neuroanatomy professor during my last semester. Currently, I'm working as a lab tech/supervisor where I actually manage the entire lab and started up a small R&D initiative. Presumably i will be there up until grad school. I also tutor on the side and have tutored before for over 2 years (mainly chemistry). 3.5gpa and I am taking the GRE in Nov.

- assuming avg GRE scores, would I be a competitive candidate for most PhD programs? I feel under prepared and worried I might biff the test.

- what is the best way to check out programs taking place around the country and what kind of research is happening? Would it be appropriate to reach out to professors there and ask to discuss their research and my candidacy over Skype?

- is it uncommon to join in spring? Most deadlines for fall enrollment are approaching fast. I feel wholly unprepared to be sending out applications but I also don't like the idea of waiting an entire year for the next cycle--plus the additional ~8months before classes even begin.

- any other words of advice from someone on the other side of the fence.
