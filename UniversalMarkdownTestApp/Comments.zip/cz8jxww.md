>ask for a heavy metal test for your blood if you haven't already

/u/sick_as_fuckk this is the right answer.