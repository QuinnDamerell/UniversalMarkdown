Username: /u/54321modnar

General Field: Medicine

Specific Field: Exercise Physiology

Particular areas of research: Functional Movement, Causes for Spinal Fusion failure (Adjacent segment degeneration) Clinical Researcher 2 years, [Licensed CSCS ](http://www.nsca.com/Certification/CSCS/)

Education: Doctorate of Physical Therapy, BS Exercise Science

Comments:  [1](https://www.reddit.com/r/science/comments/1y6i53/narcolepsy_confirmed_as_an_atuoimmune_disease/cfhvt0s), [2](https://www.reddit.com/r/askscience/comments/1m68jr/when_areas_of_our_body_swell_due_to_injury_why_is/cc6aij1), [3](https://www.reddit.com/r/askscience/comments/1m68jr/when_areas_of_our_body_swell_due_to_injury_why_is/cc6cm3h) Outside : [4](https://www.reddit.com/r/rehabtherapy/comments/2dy93c/yoga_after_spinal_fusion/cjupxuu)