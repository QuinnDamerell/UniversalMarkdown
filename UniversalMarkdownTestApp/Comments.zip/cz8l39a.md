1.49 billion more and the problem can be solved.

And to think that nobody will go to jail for this.