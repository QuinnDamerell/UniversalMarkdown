Username: /u/thermos26

General Field: Social Sciences

Specific Field: Paleoanthropology

Research Area: Hominin Paleoecology

Education: PhD Student (4th year)

Comments: [1](https://www.reddit.com/r/AskAnthropology/comments/3ld7h9/do_you_think_homo_naledi_was_buried/cv61bdq), [2](https://www.reddit.com/r/science/comments/32rgt3/scientists_working_in_east_africa_say_theyve/cqecjnh), [3](https://www.reddit.com/r/science/comments/2xxgn4/oldest_human_homo_fossil_discovered_scientists/cp4xak3), [4](https://www.reddit.com/r/science/comments/2k0nnm/neanderthals_and_humans_first_mated_50000_years/clha2sg), [5](https://www.reddit.com/r/science/comments/2buuuj/1millionyearold_artifacts_found_in_south_africa/cj9tls4)

I also have a flair in /r/science 