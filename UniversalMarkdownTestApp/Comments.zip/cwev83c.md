Username: /u/thatguy7242

General Field: Medicine

Specific Field: Interventional Cardiology

Research Area: CAD, PVD, Structural Heart Disease

Education: MD, FACC, FSCAI

Comments: [1](https://www.reddit.com/r/Cardiology/comments/3cczzm/research_overturns_basic_beliefs_about/ct4inxe)

[2](https://www.reddit.com/r/Cardiology/comments/3can2w/tools_and_techniques_for_angioplasty_of_anomalous/ct4ir8e)

[3](https://www.reddit.com/r/news/comments/3qaus5/half_of_all_surgeries_include_drug_error/cwdk1v4)

[4](https://www.reddit.com/r/Cardiology/comments/3ptgzc/having_a_heart_cath_done_next_week_and_im/cw9e8ii)

[5](https://www.reddit.com/r/Cardiology/comments/3ptgzc/having_a_heart_cath_done_next_week_and_im/cwa15p5)


