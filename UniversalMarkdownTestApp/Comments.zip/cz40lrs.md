Username: /u/ericgraves

General field: Mathematics

Specific field: Information Theory

Research Area: Shannon Theory & Information Theoretic Security

Education: PhD. Post Doc.

Comments:
[1](https://www.reddit.com/r/askscience/comments/41mtnz/whats_the_difference_between_fisher_information/cz3zpv9),
[2] (https://www.reddit.com/r/askscience/comments/401ubu/in_deal_or_no_deal_when_you_get_to_the_end_just/cyr1007),
[3](https://www.reddit.com/r/askscience/comments/3yr7ee/how_does_file_compression_work/cygq7c2),
[4](https://www.reddit.com/r/askscience/comments/3y8r77/how_are_satilites_that_are_very_far_away_able_to/cyblynf),
[5](https://www.reddit.com/r/askscience/comments/3y8r77/how_are_satilites_that_are_very_far_away_able_to/cybn6lf),
[6](https://www.reddit.com/r/askscience/comments/3y8r77/how_are_satilites_that_are_very_far_away_able_to/cybyafe),
[7](https://www.reddit.com/r/askscience/comments/3y7g89/if_for_smooth_video_you_need_24_fps_what_is_the/cybhe1u),
[8](https://www.reddit.com/r/science/comments/3uucjb/researchers_establish_the_worlds_first/cxkdzeg).