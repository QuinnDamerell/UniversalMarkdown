Username: /u/RioAbajo

General field: Social Sciences

Specific field: Archaeology

Areas of Research: U.S. Southwest and Colonialism

Education: MA in Archaeology. Current PhD student.

Comments: [1](https://www.reddit.com/r/askscience/comments/35lo2f/when_we_date_ancient_artifacts_like_old_statues/cr78j69), [2](https://www.reddit.com/r/AskHistorians/comments/3cyo18/is_there_any_connection_between_the_exodus_of_the/ct0hi6q), [3](https://www.reddit.com/r/AskHistorians/comments/2z619p/is_it_true_that_mexican_catholicism_is_strongly/cpg9jxl), [4](https://www.reddit.com/r/AskHistorians/comments/2w6476/aside_from_huntingeatingsleepinghaving_sex_what/coo2gqz).