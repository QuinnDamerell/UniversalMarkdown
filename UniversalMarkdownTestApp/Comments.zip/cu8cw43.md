Username: pocketni

General field: Social sciences

Specific Field: Political science

Research Area: Comparative political behavior

Education: Masters in East Asian Studies, Ph.D. Candidate in Political Science 

Comments: [1](https://www.reddit.com/r/todayilearned/comments/31ggzr/til_people_think_more_rationally_in_their_second/cq1s4xi), [2](https://www.reddit.com/r/askscience/comments/3hhv12/how_do_children_who_are_exposed_to_multiple/cu8bu7n), [3](https://www.reddit.com/r/AskHistorians/comments/1xm3xs/escaping_to_communism/cfd69y1)