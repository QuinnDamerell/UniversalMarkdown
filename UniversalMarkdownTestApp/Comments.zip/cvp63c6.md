Username: /u/Owls_with_towels

General field: Biology

Specific field: Marine & Fisheries Ecology

Particular areas of research including historical: Deep sea fish, crustaceans, fish parasites & diseases, mathematical modelling.

Education: PhD + 15 years grinding.

Comments: [1](https://www.reddit.com/r/askscience/comments/2rhsu0/why_are_deep_sea_fishs_uglier_and_less/cng4e8s) , [2](https://www.reddit.com/r/askscience/comments/qqt0y/why_is_it_that_people_cant_eat_most_raw_meats/c3zrj2c) , [3](https://www.reddit.com/r/askscience/comments/oy1gq/why_does_seafood_go_bad_so_quickly/c3l1pug) , [4](https://www.reddit.com/r/askscience/comments/2rhsu0/why_are_deep_sea_fishs_uglier_and_less/cng7hk2) .