Username: /u/radarksu


General Field: Engineering


Specific Field: Architectural, MEP


Research Area: HVAC Design


Education: MS Architectural Engineering


Comments: 
https://www.reddit.com/r/askscience/comments/3siyte/what_is_the_difference_between_steam_fog_and_100/cwy8ps9


I also have /r/science flair.

(edit: formatting)