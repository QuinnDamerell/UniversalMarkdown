[They did.](http://www.abc12.com/home/headlines/Man-gets-company-to-donate-38000-water-bottles-to-Flint-schools-331879681.html)  Probably didn't see anything on Reddit though because of the anti Nestle circle jerk.

And as a former Nestle Waters employee, I can guarantee they've ramped up production in plants that ship to the area.  Any time there was a possible hurricane in the gulf, there would be dozens of extra trucks every day to bring it to those areas.

If I was their PR director though, I'd certainly donate more.  This is *easy* good PR material.