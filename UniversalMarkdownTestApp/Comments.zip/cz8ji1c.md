One of the things I've always loved about Pearl Jam is how active they are in social causes. Many of their endeavors can be seen as "left" leaning but either way they have always used their fame to help out causes they find worthy.

It's always nice to see famous people put that fame to the benefit of others.