And now my bitter hands cradle broken glass

Of what was everything