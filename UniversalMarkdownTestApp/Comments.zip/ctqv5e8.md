Username: wallacethedog

General Field: Physics

Specific Field: Astrophysics

Research Area: Star Formation & Galaxy Evolution

Education: 2nd year Ph.D. student

Comments: [1](https://www.reddit.com/r/askscience/comments/3e87hm/what_is_the_theoretical_mass_whereby_when_a_star/ctdqfcr), [2](https://www.reddit.com/r/askscience/comments/3cam08/in_images_of_distant_galaxy_what_are_the_things/csudybj), [3](https://www.reddit.com/r/askscience/comments/363lox/are_there_habitable_zones_of_galaxies/crbbp54), [4](https://www.reddit.com/r/askscience/comments/364inf/if_light_and_radio_waves_are_both_electromagnetic/crbc7l2), [5](https://www.reddit.com/r/askscience/comments/35m95y/what_is_the_lowest_possible_orbit_around_the_earth/cr6250f), [6](https://www.reddit.com/r/askscience/comments/35fas0/what_is_the_terminal_velocity_of_a_standard_sized/cr5kirv), [7](https://www.reddit.com/r/askscience/comments/32vqkx/why_do_negatively_charged_ions_lose_an_electron/cqfnu10), and [8](https://www.reddit.com/r/askscience/comments/3fobjb/how_would_an_electroweak_star_look/ctquy2o).