Username: /u/DMos150

General Field: Earth Science

Specific Field: Paleontology

Particular areas of research/expertise: Evolution; Vertebrate paleontology (specifically reptiles) 

Education: Master’s Degree

I also have flair in r/science: MS | Paleontology

Comments: 

Paleontology/Evolution: [1]( https://www.reddit.com/r/explainlikeimfive/comments/3rfjza/eli5_what_triggered_the_supergrowth_of_the/cwo5xj0), [2]( https://www.reddit.com/r/explainlikeimfive/comments/3ua9g1/eli5_how_did_a_single_cell_that_replicates_its/cxd7a4f), [3]( https://www.reddit.com/r/explainlikeimfive/comments/3rjm0u/eli5_how_evolution_works/cwot94u), [4](https://www.reddit.com/r/askscience/comments/3yiupe/how_is_it_possible_that_organisms_evolved_the/cyem53y) [5]( https://www.reddit.com/r/explainlikeimfive/comments/3rl4z5/eli5_why_did_the_earlier_human_ancestors_go/cwp263t), [6]( https://www.reddit.com/r/explainlikeimfive/comments/3pmpdh/eli5_how_does_one_animal_know_if_it_is_the_same/cw7l5ic), [7](https://www.reddit.com/r/askscience/comments/3uvvu7/what_is_the_earlierst_true_bird_we_know_of/cxjf8qk)

Earth Science: [1]( https://www.reddit.com/r/askscience/comments/3qs1gm/what_are_the_differences_between_plate_boundaries/cwia2nf), [2]( https://www.reddit.com/r/askscience/comments/3rjmx2/why_isnt_the_entire_length_of_the_colorado_river/cwoscrj), [3](https://www.reddit.com/r/askscience/comments/3vutki/how_do_we_know_what_the_earths_mantle_core_etc/cxr79b1), [4](https://www.reddit.com/r/explainlikeimfive/comments/3wiuww/eli5_how_do_meteors_leave_the_asteroid_belt/cxwivdg)

EDIT: added more comments.