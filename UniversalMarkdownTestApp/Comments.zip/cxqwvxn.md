Username: [/u/ha2ha3ha4](https://www.reddit.com/user/Ha2ha3ha4/)

General Field: Neuroscience

Specific Field: Neuropsychopharmacology

Research field: Neuromodulators

Education: 1st year Ph.D student

Comments: [1](https://www.reddit.com/r/askscience/comments/3vm7rk/how_similar_or_different_are_the_female_and_male/)
[2](https://www.reddit.com/r/askscience/comments/3vnc7p/neuroscience_how_does_the_brain_address/)
[3](https://www.reddit.com/r/askscience/comments/3vpqjr/how_did_certain_facial_expressions_become//)
[4]
(https://www.reddit.com/r/askscience/comments/3vxbm9/can_we_naturally_exhaust_our_neurotransmitters/)
[5]
(https://www.reddit.com/r/askscience/comments/3utyng/does_your_sleeping_position_affect_your_posture/)