Username: /u/Ollie2220

General Field: Physics (With Philosophy)

Specific Field: Cosmology

Particular Areas of Research including historical: Dark Energy, Gravity and General Relativity

Education: Masters (Gravity, Particles and Fields), BSc (Physics with Philosophy)

Comments: [1](https://www.reddit.com/r/kurzgesagt/comments/3fl4wf/dark_energy/ctqz10c) [2] (https://www.reddit.com/r/kurzgesagt/comments/3ck7e8/dark_energy_and_dark_matter/) [3](https://www.reddit.com/r/kurzgesagt/comments/3ck7e8/dark_energy_and_dark_matter/csyp4mn) [4] (https://www.reddit.com/r/kurzgesagt/comments/3ck7e8/dark_energy_and_dark_matter/cthstd4) [5]
(https://www.reddit.com/r/askscience/comments/3foliv/could_i_get_a_more_clear_and_in_depth_explanation/ctsfguj)

I understand these posts are not all in /r/askscience , however I will be spending more time on this subreddit to contribute now. 



