I changed subfields a while ago rather dramatically, update flair pls?

Username: /u/Xenneract

General field: Chemistry

Specific field: Chemical Physics

Particular areas of research: Ultrafast Spectroscopy, Liquid Dynamics

Education: M.Sc., pursuing Ph.D.