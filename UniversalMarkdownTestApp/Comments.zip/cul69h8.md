Username: [/u/camram07](https://www.reddit.com/user/camram07/)

General field: Social Sciences

Specific field: Political Science

Particular areas of research include: American political institutions, judicial politics, game theory, time series analysis, judgment and decision making in politics 

Education: PhD in Political Science

Comments: [1](https://www.reddit.com/r/AskSocialScience/comments/3iuy7q/what_motivates_judges_to_perform_well_in_their/), [2](https://www.reddit.com/r/AskSocialScience/comments/3h0pji/do_economists_and_political_scientists_really/)

Experience: Assistant professor of political science at large American research university