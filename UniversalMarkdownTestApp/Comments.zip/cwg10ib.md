Username: McDingus69

General Field: Medicine

Specific Field: Internal Medicine

Research Area: Mainly diet and exercise in aging populations

Education: 2nd year MD student

Comments: [1 as OP](https://www.reddit.com/r/askscience/comments/1f1zug/immortal_lobsters/), [2](https://www.reddit.com/r/oddlysatisfying/comments/3p0xtm/this_bowl_of_marshmallowsonly_lucky_charms/cw2em2q), [3](https://www.reddit.com/r/todayilearned/comments/3oqaxy/til_race_means_a_subgroup_within_a_species_which/cvzrf2o), [4](https://www.reddit.com/r/todayilearned/comments/3oqaxy/til_race_means_a_subgroup_within_a_species_which/cvzrf2o), [5](https://www.reddit.com/r/medicine/comments/3ak0s3/metformin_b12_inhibitor_or_brain_cell_grower/csdf0ge), [6](https://www.reddit.com/r/Christianity/comments/3nhd47/is_smoking_a_pack_per_day_of_cigarettes_a_sin/cvo3vrx)