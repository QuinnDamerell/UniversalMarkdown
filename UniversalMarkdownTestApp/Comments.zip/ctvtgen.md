Username: /u/TanithRosenbaum

General Field: Chemistry

Specific Field: Quantum Chemistry

Particular areas of research including historical: Simulation of ligand exchange mechanisms in solvated complexes, simulation of phase transitions (current)

Education: Diploma in General chemistry (equivalent to B.Sc + M.Sc in the US), currently employed as PhD student/research scientist in the area of computational chemistry (4th year right now).

Comments: [1](https://www.reddit.com/r/askscience/comments/29elyo/in_chemistry_what_is_the_difference_between_a/cikajy6),[ 2](https://www.reddit.com/r/askscience/comments/3g7bca/is_this_right_theres_48_people_per_square/ctvt3ue), [3](https://www.reddit.com/r/askscience/comments/28np0u/is_there_a_way_to_visually_interpret_smells/cidin7w), [4](https://www.reddit.com/r/askscience/comments/1v5n5k/is_there_any_material_that_is_accessible_to/cept1fr), [5](https://www.reddit.com/r/askscience/comments/25p2ld/is_fire_unique_to_an_oxygen_rich_atmosphere_are/chjeznc), [6](https://www.reddit.com/r/askscience/comments/28t7r6/what_makes_biodegradebel_plasics_biodegradebel/cieql85)