User name: /u/bearsnchairs 

General field: Chemistry

Specific field: Nanomaterials

Particular areas of research include: Nanomaterial synthesis, characterization, drug delivery, design of novel nanomachinery. Past research includes biomonitoring, volatile organic compound analysis, gas chromatography/mass spectrometry.

Education: PhD Candidate

Comments: [1](https://www.reddit.com/r/askscience/comments/1qlzxa/what_happens_to_blood_samples_after_they_are/cde6pr5) [2](https://www.reddit.com/r/askscience/comments/2tgo8r/do_the_harmful_chemicals_that_are_listed_in/cnz043a) [3](https://www.reddit.com/r/askscience/comments/1jmvsb/if_elements_like_radium_have_very_short_half/cbgdc3l)

Outside of /r/askscience : [1](https://www.reddit.com/r/science/comments/2e9x0j/smokers_consume_same_amount_of_cigarettes/cjxn6pu) 