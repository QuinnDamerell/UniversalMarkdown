He's the leader of the state. A large city was poisoned under his watch. It may not have been his "fault" but he sure as shit is responsible for it.

Edit- Synder apologists to the rescue. 