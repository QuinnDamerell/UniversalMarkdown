Username: CubicZircon

General Field: Mathematics

Specific Field: Number theory/Cryptography

Area of expertise: Elliptic curves, algebraic number theory, computational number theory

Education: Doctorate + 5 to 10 years of research.

Comments: [Pollard rho](https://www.reddit.com/r/askscience/comments/3vwu0y/why_is_cycle_detection_the_key_to_integer/cxsloh7), [mathematics of music](https://www.reddit.com/r/askscience/comments/3rcwkf/why_arent_their_black_keys_in_between_bc_and_ef/cxsmkmc), [quantum computers](https://www.reddit.com/r/askscience/comments/3vw37z/can_quantum_computers_perform_algorithms_that/cxrd6li), [public-key cryptography](https://www.reddit.com/r/askscience/comments/3slxjb/mathematically_what_goes_on_to_make_public_key/cwyt9ng).