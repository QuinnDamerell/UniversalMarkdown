Incorrect. Some models are NSF certified to remove heavy metals, including lead:

http://www.abc12.com/home/headlines/People-voice-their-concerns-about-Brita-filters--330995452.html?device=phone&c=y