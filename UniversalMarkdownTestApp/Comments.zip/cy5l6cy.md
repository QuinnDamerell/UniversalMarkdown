Hi, I have a flair in /r/Science.

* Username: /r/ratthing
* General Field:  Neuroscience
* Specific Field:  Behavioral neuroscience
* Particular areas of research including historical:  Pain and analgesia processing in mammalian brain; Serotonin modulation in relation to depression and anxiety; Simulation of brain functions in computers
* Education: Ph.D., Behavioral neuroscience
* Comments [1](https://www.reddit.com/r/askscience/comments/3c8d1u/i_can_type_without_looking_at_the_keyboard_but/), [2](https://www.reddit.com/r/askscience/comments/3xjbqr/what_causes_the_compulsion_to_frequently_check/), [3](https://www.reddit.com/r/askscience/comments/3x04ni/if_an_addict_stops_using_an_addictive_substance/), [4](https://www.reddit.com/r/askscience/comments/3hbcvi/how_can_we_be_sure_the_speed_of_light_and_other/)
