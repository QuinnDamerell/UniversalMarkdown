This depends upon where you are, in the UK for example we have what are called Doctoral Training Centres (DTCs). These are basically a PhD program with an extra year before you begin your PhD project. This first year is like a masters, there are some taught aspects and a research project basically it is like a mini-training year. It also comes with funding for the full time, places can be competetive however getting onto one with just is a BSc is possible.     


  
  There might be similar options in other countries to these DTCs.
  
However, with regards to needing a masters before starting a PhD it is not always necessary, some institutions will have it as a requirement, however a supervisor can override that if you talk to them and they are interested in working with you. I didn't do a masters degree and am on a PhD place in a high ranked university over here. Just be warned that it will be more competetive and could be harder to get noticed. 

  The pros of doing a masters are generally: It gives you experience of running a research project, working within a research group, some courses include more teaching time that can give you additional information regarding either topics that were covered briefly or not covered as they are considered too complex or out of the themes of the undergraduate course.
  
Cons can be: stress, not just with research or exams but also financially, fully funded masters programs are not that common (especially in the UK). This can put some people off going further down post-graduate route. 

  My suggestion to you would be to sit down with your tutors, ones who you have interacted with the most, and or wish to work with. Talk through the options, as they will have advice that is more tailored to your course, choice of masters programme. You could also ask them whether there are any internships or places for a lab assisstant over holidays so that you can get more experience of working within a group, and it will help you guage whether jumping in the deep end and not doing a masters is a viable option. 

Any further questions or if you would like a bit more clarity on certain points, please feel free to ask.