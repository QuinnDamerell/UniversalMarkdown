Username: kjoeleskapet

General field: Social Sciences

Specific field: Theoretical Linguistics

Masters research in adult language acquisition and PhD research in West Germanic morphology.

Education: PhD (all done!) in Theoretical Linguistics. Developed curriculum for Danish public schools' Spanish/French/English high school-level programs.

Comments: [1](https://www.reddit.com/r/askscience/comments/3ai5ge/what_is_a_more_effective_way_of_learning_a_new/cshyvtx), [2](https://www.reddit.com/r/askscience/comments/3duhpn/why_do_we_use_the_word_volume_to_refer_to_how/ct99vye), [3](https://www.reddit.com/r/askscience/comments/uukxt/when_speaking_english_my_voice_is_lower_than_when/c4yqptf), [4](https://www.reddit.com/r/askscience/comments/3ap0xx/why_do_languages_even_across_different_language/cshyhkz), [5](https://www.reddit.com/r/askscience/comments/3e6pgk/in_the_past_few_decades_have_different_dialects/ctdpdwr)