Username: /u/aayush387

General field: Medicine

Specific field: Dermatology

Particular area of research: Vitiligo and genodermatoses

Education: MBBS, MD

Comments: [1](https://www.reddit.com/r/askscience/comments/3dlm6a/why_are_steroids_used_to_treat_severe_allergic/) [2](https://www.reddit.com/r/askscience/comments/3ds3zw/what_determines_the_exact_placement_of_acne/) [3](https://www.reddit.com/r/askscience/comments/3cs3nd/why_does_the_rash_from_meningitis_not_blanche/) [4](https://www.reddit.com/r/askscience/comments/3bry48/by_what_mechanism_is_hiv_transmitted_from_mother/)

Have flair in r/science