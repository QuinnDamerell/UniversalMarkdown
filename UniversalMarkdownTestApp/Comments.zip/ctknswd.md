   Username: electric_ionland

   General field: Engineering  
   Specific field: Electric propulsion/Ion thruster  
   Particular areas of research include Hall effect thrusters, Cold Plasmas, Magnetohydrodynamics.  
   Education: MS in aerospace engineering, currently in a PhD on Hall effect thrusters  
   Comments: [1](https://www.reddit.com/r/askscience/comments/3dfir7/why_doesnt_nasa_use_nuclear_powered_spacecraft/ct53zpn), [2](https://www.reddit.com/r/askscience/comments/3dfir7/why_doesnt_nasa_use_nuclear_powered_spacecraft/ct58887), [3](https://www.reddit.com/r/askscience/comments/3ar461/what_limits_the_specific_impulse_of_an_ion_engine/csfszk2), [4](https://www.reddit.com/r/askscience/comments/38vfkv/is_there_any_material_real_or_theoretical_that/cryamtv?context=3), [5](https://www.reddit.com/r/askscience/comments/376onb/how_can_a_moving_laser_with_a_specific_wavelenght/crkdc03).


Outside /r/askscience: [1](https://www.reddit.com/r/ScienceImages/comments/3e89o3/a_laboratory_hall_effect_thruster_ion_thruster/) (post with various comments), [2](https://www.reddit.com/r/space/comments/37r3oc/a_laboratory_hall_effect_thruster_ion_thruster/) (fairly succeful post on /r/space where I explain what I do).