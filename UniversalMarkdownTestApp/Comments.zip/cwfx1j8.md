Wow so many questions. Even within life sciences, this is very field specific. I will pick and choose a few of your questions:


1) I think most undergraduates are ignorant about how the university system works.

2) "best" is always very relative and I prefer to group programs like "top 10". Of course, rankings do exist: [US News](http://grad-schools.usnews.rankingsandreviews.com/best-graduate-schools/top-science-schools/molecular-biology-rankings), [PhDs.org](http://www.phds.org/rankings/genetics). General university rankings are also a good proxy for individual programs imo.

4) If your goal is academia then BS>PhD.

6) 5 years is probably ideal in the US. 8 is too long

9) If your goal is academia then yes.

10) Depends on the field.

11) Double major.

12) UK undergraduate (though this is more of a toss up), US graduate