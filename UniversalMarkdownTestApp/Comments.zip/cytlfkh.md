Username: /u/fsmpastafarian 

General field: Psychology

Specific field: Clinical Psychology

Particular areas of research including historical: Health psychology and psychosomatic medicine, neuropsychology, trauma

Education: doctor of psychology (PsyD)

Comments: [1](https://www.reddit.com/r/science/comments/3waj3f/talking_therapy_as_effective_as_antidepressants/cxuyuqx), [2](https://www.reddit.com/r/science/comments/3ylus8/johns_hopkins_university_study_reveals_that/cyejei2) , [3](https://www.reddit.com/r/science/comments/3ylus8/johns_hopkins_university_study_reveals_that/cyen06q) , [4](https://www.reddit.com/r/science/comments/3wsqn4/antidepressants_taken_during_pregnancy_increase/cxysxoi), [5](https://www.reddit.com/r/psychology/comments/3vxyrb/antidepressant_that_stimulates_neurogenesis/cxrx8qi) .