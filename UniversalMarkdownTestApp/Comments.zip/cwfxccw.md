If it binds DNA, it's better to be safe than sorry.  That's how my lab treated it.

