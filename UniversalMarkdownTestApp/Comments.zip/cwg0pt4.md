One of my undergraduate classmates had similar interests to yours, and after graduation he went to work for Abbott labs in a management training program. He eventually got an MBA and now does project management for them, essentially administrating the people who do the actual research.

There are also biotech focused MBA programs (Carnegie Mellon has one, for example).