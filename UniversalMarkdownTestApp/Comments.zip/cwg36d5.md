Hi panelists,  
  
I'm currently in my sixth year of a post-bachelor's Ph.D. program. In that time, the department I entered grad school to study with has been dissolved and re-purposed into another department, and 2 of my 3 faculty advisors have left for greener pastures. I've worked on drafts for several papers, all but one of them never made it to publication for various reasons. I've been working for almost 2 years to put together a publication of the work I've been doing, but it still seems to be going nowhere and my advisor doesn't seem committed to getting it out the door. I lose my RA funding next semester when our grant expires.    
  
Is it worth sticking it out to try and graduate at this point? **Will I be "employable" as a PhD with almost nothing to show for my time besides my dissertation?** Is "mastering out" a good option?  
  
