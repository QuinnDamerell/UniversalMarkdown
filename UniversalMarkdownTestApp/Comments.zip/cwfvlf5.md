The school's reputation is only one factor. If you are interested in following a graduate program, are you considering a taught program to work in industry? A research program to go into industry? Or a research program to stay in academia and research?    
 
   
  As each will have different factors that you should consider. For instance if you want to do a taught masters then head into industry, you could investigate courses that are accredited, or look for ones where the academics have a lot of industrial links. This could be the same for if you wished to do a masters with a research goal, then industrial links or academics who publish a lot with industrial funding or partnerships. 

 A key thing from my experience is not just about the school's reputation, whilst I looked at only those who had good reputations I was more concerned with the reputation of the people I would be working with. They are the ones who can start to open doors for your career, and get your name out there. 