Username: /u/ukitel

General field: Biology

Specific field: Molecular Oncology, Cell Biology, Genetics, Microscopy

Particular areas of research including historical: Mitosis, Genomic instability, Tumorigenesis, Translational research, Animal models

Education: PhD completed. Just started postdoc

Comments: [1](https://redd.it/3iax7q) only one but it's an AMA with 170+ answers, I'm new