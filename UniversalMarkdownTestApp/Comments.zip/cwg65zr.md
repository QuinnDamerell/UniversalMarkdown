> I've been working for almost 2 years to put together a publication of the work I've been doing, but it still seems to be going nowhere and my advisor doesn't seem committed to getting it out the door. I lose my RA funding next semester when our grant expires.
> 
> 
> 
> Is it worth sticking it out to try and graduate at this point? Will I be "employable" as a PhD with almost nothing to show for my time besides my dissertation? Is "mastering out" a good option? 

You won't quite have nothing besides your dissertation, but it's close. 

I would GTFO as fast as possible, the fact that you've spent 6 years doing (sorry) work that no one will ever see or care about is alarming.

Find a job. Advertise yourself as a dissertator or whatever. Go to your advisor and say, "I have a job. I want my PhD, now." You've spent 6 years, you've done what apparently seems to be reasonable work. Your advisor apparently doesn't care about you or your life progress. You need to get away as fast as possible, and them giving you a "pity PhD" is the easiest way for all involved.