Username: /u/wookietiddy
General Field: Mechanical Engineering
Specific Field: Mechatronics
Particular areas of research including historical: Physics, Mechanics, Strain, Stress, Structural Engineering, Materials Engineering, Controls and Mechatronics
Education: Master of Science, Mechanical Engineering
Comments: [1](https://www.reddit.com/r/explainlikeimfive/comments/2q93m6/eli5_so_if_everything_in_the_universe_expanded/cnp7fis) I'm pretty new.