Username: /u/songbolt

General field: Physics

Specific field: [Medical Physics](http://www.aapm.org/medical_physicist/default.asp)

Particular areas of research: carbon ion radiation therapy; charged particle therapy; adaptive radiotherapy, computer modeling, image registration, patient positioning

Education: [CAMPEP](http://www.campep.org)-accredited Masters of Medical Physics degree, 2nd Year PhD student.

Comments: [1](https://www.reddit.com/r/askscience/comments/3tpjvw/in_what_sense_is_a_black_hole_really_a_hole_isnt/cx8yw5f), [2](https://www.reddit.com/r/math/comments/3twd5u/how_does_one_solve_this_set_of_nonlinear/), [3](https://www.reddit.com/r/askscience/comments/3toyep/can_hitting_your_muscles_make_them_stronger/cx8yizj). (I am new to Reddit. I am volunteering in case there are no more experienced Medical Physicist Redditors and you want one; I understand you want more experience.)