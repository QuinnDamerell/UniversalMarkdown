Username: /u/Pivazena

General field: Biology

Specific field: Quantitative genetics

Particular areas of research including historical: Behavioral genetics, statistics, natural variation, evolutionary biology, neuroscience, GWAS.

Education: PhD, 2.5 years of postdoc

Comments: [1](https://www.reddit.com/r/BabyBumps/comments/3br5l5/actually_its_a_sex_ultrasound_not_gender/csorpum), [2](https://www.reddit.com/r/AskScienceDiscussion/comments/3g0ed0/organisms_with_xxyy_xxy_or_xyy_chromosomes_and/ctttlme), [3](https://www.reddit.com/r/science/comments/3a6bn8/researchers_discover_first_sensor_of_earths/csa9onn), [4](https://www.reddit.com/r/askscience/comments/36fpv7/do_fish_evolve_slower/cre6hi4), [5](https://www.reddit.com/r/AskReddit/comments/3hw3vu/phds_of_reddit_what_is_a_dumbed_down_summary_of/cubi1kh), [6](https://www.reddit.com/r/SpeculativeEvolution/comments/2ssd0x/speculative_genetic_engineering_ambitions_of_a/crdg2qd), [7](https://www.reddit.com/r/biology/comments/365kzx/another_and_more_specific_question_for_you_how/crddrri),[8](https://www.reddit.com/r/askscience/comments/3k67ym/is_the_symmetry_on_an_animals_coat_in_any_way/cuvtvo3)