Username: /u/DrJPG

General field: Psychology

Specific field: Cognitive/Behavioral Psychology

Particular areas of research including historical: anxiety/depression, psychological assessment, pop culture
Education: Doctorate (PsyD) in Clinical Psychology, Private Practice for several years

Comments: [1](https://www.reddit.com/r/askscience/comments/3n7yjt/do_animals_in_war_like_specialized_search_dogs/), [2](https://www.reddit.com/r/askscience/comments/3niquo/can_behavioural_therapy_techniques_be_used_to/), [3](https://www.reddit.com/r/AskScienceDiscussion/comments/3n8ie1/is_there_any_psychological_or_sociological/), [4](https://www.reddit.com/r/askscience/comments/3m0kxq/why_do_girls_typically_have_better_handwriting/)
