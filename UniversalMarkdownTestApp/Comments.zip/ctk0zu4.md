Username: /u/babubadar 

General field: Biochemistry

Specific field: Genome Stability

Particular areas of research including: Epigenetics and genome stability, DNA damage and repair, oncogenesis and proteomics

Education: PhD student

Comments: [1](https://www.reddit.com/r/askscience/comments/3ezjy2/does_the_frequency_of_alleles_that_are_dominate/) I'm so new!