Woohoo! West coast best coast!

Except for the giant toxic cloud.