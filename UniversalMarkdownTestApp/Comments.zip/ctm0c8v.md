username: /u/hawkcawcaw  

General Field: Engineering  

Specific Field: Materials Science & Engineering (Metallurgy)

Area of Research: Failure mechanisms of alloys including fatigue, corrosion, environmental cracking, etc.  

Education: MSc student (expected 2016).  Four years of industry experience.  

Comments:  [1](https://www.reddit.com/r/askscience/comments/3ezftn/why_are_some_metals_stronger_than_others_why_isnt/ctm603h), [2](https://www.reddit.com/r/askscience/comments/3exqjv/what_materiel_is_both_flexible_and_able_to_keep/ctm2x0j), [3](https://www.reddit.com/r/askscience/comments/3dh323/what_causes_a_material_to_shatter_how_is_this/ctm6lf1)

Let me know if there is anything else required.