I've got flair in /r/Science and /r/EverythingScience

Username: [/u/RealityApologist](https://www.reddit.com/user/RealityApologist)

General field: Earth and planetary sciences

Specific field: Climate science / complex systems theory

Particular areas of research: Geoengineering, computational climate modeling, foundations of climate science

Education: PhD from R1; currently post-doctoral researcher in an earth science department at an R1

Some comments: [1](https://www.reddit.com/r/askscience/comments/3yj330/why_does_a_2_degree_temperature_change_have_such/cyedisi) [2](https://www.reddit.com/r/science/comments/2oczj8/science_ama_series_we_are_dr_david_reidmiller_and/cmmj4gj) [3](https://www.reddit.com/r/EverythingScience/comments/2oigq7/newsweeks_cover_story_this_week_is_on/cmnf86n) [4](https://www.reddit.com/r/askscience/comments/2ou5po/what_does_global_warming_do_exactly/cmrfm4i) [5](https://www.reddit.com/r/EverythingScience/comments/30jwqv/geoengineering_climate_change_by_design_recorded/)