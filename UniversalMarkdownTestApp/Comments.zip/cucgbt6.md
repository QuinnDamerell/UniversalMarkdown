username: plorraine

general field: Physics

specific field: Physics / Optics / biomedical physics

22 years as a research physicist working on aerospace, energy, and biomedical applications

education: PhD physics