First two years are so have a lot of classes.

You attend a lot of seminars and read a lot of cutting edge research.

You are your own boss.

Then you have the hard part. You keep trying a whole bunch of different ways to try to create one (relatively) small innovation that takes about 100 pages to show its worth. Many times you end up finding people's cutting edge research is lacking in some way. Eventually you may come up with some general improvement to help lots of algorithms or whatever. Suddenly, 5 years have gone by and you've got a piece of paper that says atomant30, PhD, expert at something nobodies ever heard.

What practical skills you likely get:

1. TA: You prepare and run meetings, essentially, as a teaching assistant.
2. Reading: You get good at reading scientific publications, that is skimming them for important material, for the most part.
3. Programming: You're gonna learn how to program and even better, you're gonna learn how to download lots of people's broken source code and get it working on your system to fix your problems.
4. Begging for money. (Grants)
5. The "joy" of our current peer review system.
6. Expert at some obscure field. Some people may invite you to talk at their seminars about things you stopped caring about 6+ months ago.


It might be good to get a M.S. in computer science and a project+thesis in Machine Learning. Then you're in and out in 2 years and then you can get paid to learn about machine learning. That's what I did.