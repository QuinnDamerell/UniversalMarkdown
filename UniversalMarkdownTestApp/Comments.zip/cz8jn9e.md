Teh Mannificent Hand of teh FREE MARKETT.

Rural Electrification Project? Pinko Claptrap.

US Highway system? Cold War paranoia.

Hoover Dam? Handout.