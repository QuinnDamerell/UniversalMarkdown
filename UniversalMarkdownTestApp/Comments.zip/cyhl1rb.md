Username: /u/randoguy_16

General field: Chemistry

Specific field: Organometallic Chemistry

Particular areas of research: developing metal-based catalysts for organic synthesis 

Education: PhD student

Comments: [1](https://www.reddit.com/r/askscience/comments/3ys5x4/why_is_ironiii_chloride_a_better_catalyst_of_the/), [2](https://www.reddit.com/r/askscience/comments/3yuxhw/how_do_we_know_how_organic_molecules_look_like/), [3](https://www.reddit.com/r/askscience/comments/3yu0d3/why_are_some_materials_more_hydrophobic_than/), [4](https://www.reddit.com/r/chemhelp/comments/3yesxq/for_ammonia_why_is_the_nitrogen_hybridised_sp3/)