If you want to test your water, [the test is ten bucks at the Home Depot.]( http://www.homedepot.com/p/PRO-LAB-Lead-in-Water-Test-Kit-LW107/100174134)   They were giving some kind of lead test away free at my local Home Depot, I line nowhere near Flint.  

~~If they are giving large numbers of $10 test kits away, they deserve recognition, I hope someone will comment with more info.~~

Edit, I just read the link I posted, the lab charges $40 to analyse the test, they are probably making a killing right now.  Anyway, get together with a few neighbors, the test is cheap if you share the cost.