Hi /u/silverphoinix, I would like to ask a follow-up question.

Where do you get the information regarding the reputation of the people/supervisors of the research group?

Thank you.