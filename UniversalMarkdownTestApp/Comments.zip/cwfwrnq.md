Hi,

I am a PhD student and currently changing to a Post-Doc possition.

How long, do you think, should one be a Post-Doc? 

Background: I heard from a friend that she spent 5 years as a postdoc and now has problems to find a job. She couldn't move on to tenure track and is now way to specialized for an industry job.  

So when should you change the institute or just move on to industry?
