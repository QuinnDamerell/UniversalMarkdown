1. Don't overdo student organizations. One long term or high level engagement is enough, concentrate the rest of your efforts on undergraduate research
2. You could look at this by the number of research dollars being brought in or publications being put out, but these types of rankings are largely meaningless. Look to see if you are interested in the research being done and if any key researchers in the field are at the institution
3. PhDComics
4. Depends on the field on your accumulated work experience.
5. See #1
6. Depends on the field. Non STEM is 5 years max, STEM can be up to 8 if you're particularly unlucky.
7. I promise myself 8 hours of sleep per night, I bike, and keep an active social life.
8. Don't do it? Personal plagiarism is all the rage right now in academic ethics.
9. Post-docs are mainly for those looking for a tenure track placement after graduation. It's the only time in your career where your only job is to work on publications and research. The need for a post-doc is field dependent, and lessens if you have first author papers under your belt.
10. Depends on the field, but in general, no
11. BS-MS
12. US for both, but undergraduate is self driven