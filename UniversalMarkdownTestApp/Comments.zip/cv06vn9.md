I have had panelist flair for several years now, but I am applying for a change in flair.  I have now earned an MD and am currently a resident physician in the field of Radiology, so I would like Radiology to be added to my flair.  Additionally, my research in circadian rhythms was performed five years ago and I now feel I am no more qualified than any other physician to inform laypeople about circadian rhythms, and that I am less qualified than someone who has specialized in that area more recently; therefore I would like Circadian Rhythms to be removed from my flair (I will still answer a simple question on this topic if I happen to come across it and feel my previous research is sufficient to answer the question, but I no longer feel I should be sought out as an expert in that field).

Username: /u/thecrusha

General field: Medicine.

Specific field: Radiology.

Completed degrees: MD 2015, BA Molecular Biology 2010.

(Previous) Research: Molecular mechanisms of circadian rhythms in *Homo sapiens, Mus musculus,* *Arabidopsis thaliana,* and the cyanobacterium *Synechococcus elongatus.*