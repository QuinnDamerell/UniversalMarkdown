*What do you wish you did in undergrad to better prepare for going to grad school?*

Obtained a job in a lab or at a place related to my field of study. As it stood, I had a job working in food service. I think that getting exposed to certain ways of working would have been a bit more beneficial.

*What is the difference between your undergrad and graduate social life?*

HA! For undergraduate, things were a bit more steady and routine. I worked, but maintained an active social life on the weekends and had some free time. My Masters was a little bit of the same but more restricted. I had more school/research responsibility so I mostly worked but was able to hang out with people on a regular basis and do fun stuff. I did a geology masters degree focusing on hydrological process, so I could also get away with taking equipment and going out and killing two birds with one stone: for example taking water chemistry samples while kayaking down the river. 

PhD....Well, things changed drastically with that. But that was also an artefact of me switching disciplines. I went into a PhD in water resources engineering with a background in geology. If you are unaware, geology prides itself on alcoholics and back of the envelope calculations, so the dynamic was completely different. I had to play a LOT of catch up on fundamental principles, all while learning tons of new software and putting together a research plan. This significantly reduced my social life, almost to nonexistent the first 1.5 years. In addition, circumstances also made me want to try and finish as soon as possible. So my social life approached nonexistent and I've been trying to get my mojo back over the last year. Because I managed to do a bulk of the work in my first few semesters, it has made life easier as I approach graduation. But nonetheless, even with my circumstances, a PhD can be a soul wrenching experience. Worth it in the end if its what you really want. 

*What can I (as an undergrad RA) do to make my grad student's life easier? (we're in a psych lab but I'd be happy to hear anyone's answer!)*

Don't ask them how their research is going. Just surprise them one day with a nice bottle of Chimay (blue label) and say "It's all going to be ok..." OK, that would be something I would have wanted....