Username: /u/melanostomias

General field: Biology

Specific field: Ichthyology

Particular areas of research including historical: Deep-sea fishes

Education: MSc Zoology, PhD student (in progress)

Comments: Unsure as to how to link comments. I did another AMA: 
https://www.reddit.com/r/science/comments/32sn8d  