I agree with /u/dunnp, that these answers are extremely feild specific, but I'll give you my perspective as a computational geneticist.
1) No regrets. It took me a little while to figure out what I wanted to major in but I don't regret the path I took to get to Math. I partied, played varsity sports (DIII school), took classes completely outside my comfort zone, completed the US pre-med requirements, majored in Math, concentrated in BioChem (like a minor), and graduated in 3.6 years (took a leave of absence to work in industry for 6 months). My grades from undergrad definitely reflected that I was spread pretty thin, but I think the rounding out was good for me personally and professionally.

2) Eh, worry less about this and more about where the people you want to work with are. If you want to study populations genetics, go to Stanford to study with Jonathan Pritchard or Chicago to study with John Novembre. If you want to study pharmacogenomics, go where the top researchers in that feild are. Long term, the work you do, not the school you go to, matters most. Finally, go to a program that financially supports you and join a lab that has a track record of transitioning trainees to successful careers.

3) This is way too broad. What topics within the life sciences do you love? There are few books that I know of about how to be a successful PhD candidate, run a successful lab, or on how to get grants. Mostly your excellence in these endeavors will come from experience.

4) Depends on your field. 

5) Fill your schedule with classes that will set you up for success in the career you want, but leave some room for classes that challenge you. I took a lot of math and a lot of biology, but never took a single genetics or stats class in undergrad and now I am an assistant professor of genetics and biostatistics- which is one example of how not taking something in undergrad will not necessarily restrict your options down the road. One of the best classes I ever took was post-modern Hindu film- courses like these, while not overtly relevant to your career path in a traditional sense may open your mind and make you a better academic.

6) I start to worry when students take 8 or more years. I think the ideal in the US is 5 years.

7) I try to channel stress in positive ways- going for a run and pounding pavement, for example. That doesn't always work and there have been plenty of dark moments, and I'm sure there will be plenty more. The trick is coming out on the other side, coping with failure or disappointment without letting it beat you.

8) Don't do it. Ever.

9) Whether or not to do a post doc depends entirely on your field and on your career plan. Industry jobs frequently don't require them, professorship positions frequently do. I was offered a faculty position straight out of graduate school, but I decided that the additional time developing and diversifying my skills and maturing as a project leader was worth doing a post doc anyway. I'm glad I did and it made me much more competitive when I hit the job market again 18 months later.

10,11) Depends what you want to do... 

12) There are excellent programs that provide top training in both parts of the world. Focus on figuring out what you want to do and who you might want to work with, and pick your institutions for higher learning based on those criteria and you will be fine. 