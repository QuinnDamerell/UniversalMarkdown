Hi everyone, thanks for doing this AMA.

I'm currently at a stage in my life where I finished a Masters programme in the UK in Biomedical Sciences 2 years ago, and I'm desperately trying to break in to Cancer Research, probably in the area of cellular or molecular biology. I've worked on a few short (3 month) research projects mainly involving the role that genes play in disease states, but beyond that I've never been employed in a research capacity (I am 25). 

I am really eager to get in to research, but every job that I apply for, and every funded PhD programme that I apply to, I seem to have no luck. It has been this way for 2 years and I'm concerned that perhaps my lack of experience is letting me down. I've been considering moving back home in London and trying to gain some voluntary experience in a cancer research laboratory to gain some relevant experience (currently I am in a clinical laboratory). 

Do you have any advice for someone wanting to break in to the field of molecular/cellular biology, whether it's writing for applications (i.e. what the emphasis should be on), gaining experience, or anything else that might help. I know that this is where I want to go with my life, and I want to help myself out in any way that I can.

Thanks again for any advice.