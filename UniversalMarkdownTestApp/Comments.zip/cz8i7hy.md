While that all may be true..

it's poisoning people to allow their water to be poisoned *and not even tell them about it*