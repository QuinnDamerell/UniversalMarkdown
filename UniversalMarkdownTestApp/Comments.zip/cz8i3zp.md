If it's brown drink it down.

If it's black send it back.