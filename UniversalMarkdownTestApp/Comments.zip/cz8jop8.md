Obama's the leader of the country, why not him?

Bro, actually read up on facts. The CITY did this. And the treatment didn't take into account the river's higher PH.

The EM was there because the city government had ruined itself financially.