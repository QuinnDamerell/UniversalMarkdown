> who voted these self-serving bastards into office.

Same ones who are voting for Trump
