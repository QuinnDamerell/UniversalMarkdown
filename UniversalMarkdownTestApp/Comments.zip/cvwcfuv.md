Username: /u/1AwkwardPotato  
General Field: Physics  
Specific Field: Materials Physics  
Research Area: Scanning Probe Microscopy & Lithium Ion Battery Materials  
Education: M.Sc., now 1st year Ph.D. student  
Comments: [1](https://www.reddit.com/r/askscience/comments/3n98qa/does_lightning_cause_a_power_surge_or_does/cvm5ozh) [2](https://www.reddit.com/r/askscience/comments/3bezmw/majorana_fermions_in_solid_state_how_do_they_arise/cslmipg) [3](https://www.reddit.com/r/askscience/comments/3abccu/is_graphene_currently_being_used_in_any_real/csbaxy3) [4](https://www.reddit.com/r/askscience/comments/38sg78/why_can_i_see_ulraviolet/crxronx) [5](https://www.reddit.com/r/technology/comments/2c4tws/battery_life_holy_grail_discovered_phones_may/cjc8r7s)