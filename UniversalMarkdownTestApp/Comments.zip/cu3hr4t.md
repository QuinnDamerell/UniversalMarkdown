Username: biocomputer

General field: Biology

Specific field: Developmental Biology & Epigenetics

Particular areas of research include developmenal biology, epigenetics/epigenomics, chromatin, gene regulation, genetics of intellectual disability syndromes.

Education: PhD in biochemistry and developmental biology, post doc for ~2 years

Comments: [1](https://www.reddit.com/r/askscience/comments/32hb0m/is_the_y_chromosome_really_disappearing/cqbmcvy?context=3) [2](https://www.reddit.com/r/askscience/comments/34v5rn/if_humans_and_apes_share_99_of_genes_how_are_each/cqyk18q?context=3) [3](https://www.reddit.com/r/askscience/comments/3a3wx4/in_the_study_of_epigenetics_how_do_we_know_a/cs9pe4k?context=3) [4](https://www.reddit.com/r/askscience/comments/2z3km2/how_does_the_theory_of_incremental_evolution_by/cpgauwk?context=3) [5](https://www.reddit.com/r/askscience/comments/37cpty/at_some_point_in_evolution_we_must_of_mutated/crlmgue?context=3) [6](https://www.reddit.com/r/askscience/comments/3dqwsp/is_there_any_advantage_to_having_genes_spread_out/ct8gwcv) [7](https://www.reddit.com/r/askscience/comments/3o0lkx/if_the_difference_between_the_cells_in_our_body/cvta6y8) [8](https://www.reddit.com/r/askscience/comments/3odogu/in_a_female_sex_chromosome_xx_if_the_x_that_is/cvwmm8e) [9](https://www.reddit.com/r/askscience/comments/3oud36/the_human_genome_has_about_1000x_the_base_pairs/cw140ue?context=3) [10](https://www.reddit.com/r/askscience/comments/3ucpup/gdna_preparation_why_is_fragmentation_required/cxebv90) [11](https://www.reddit.com/r/askscience/comments/3vgj2w/slug/cxorcf3) [12](https://www.reddit.com/r/askscience/comments/3wjzdv/it_seems_that_dna_mutation_creating_a_start_codon/cxxbkt0)

Also I have this flair in /r/Science: `PhD | Developmental Biology | Epigenetics`