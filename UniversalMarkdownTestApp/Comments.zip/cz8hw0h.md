CA needs to wait its turn in the horrible man-made disaster queue. 

Besides. They're fixing it. Sometime this Spring.

/s