Oceans of clean water flow through the strip.

Am I doing it right?