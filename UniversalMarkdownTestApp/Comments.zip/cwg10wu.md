> its... just so effing much. Do people really research all of this prior to application?

Yeah, a lot of people do. Applying to grad school (not in psych) was a grueling process, but it's also quite competitive, and your choice is important, so you have to invest the time. 

Professors will try to tease out if you've done your homework, and that can make a difference if they're evaluating your application. ("He doesn't seem serious/committed" vs. "he's really enthusiastic and seems like a good fit!")

And so many people have a bad experience in grad school that you want to find out as much as you can to try to avoid that. As has been said, you're committing to 4-7 years in a lab, at a university, and in a town, so you want to do everything to can to get it right.