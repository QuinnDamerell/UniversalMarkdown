/u/theratwhowouldbeking 

I'm an undergrad interested in going to a PhD program in psychology. 

Q1. How much did you know about grad school prior to going to grad school , and which things do you wish you had known? 
I ask this question because I know it's recommended to know things like course curriculum, living expenses of the area, what kind of research the professors are doing, what the lab is like, the personality/"style" of professors, and how successful alumni are post graduation, but its... just so effing much. Do people really research all of this prior to application?

Q2. How is the job market these days?  

Edit : clarification of question.