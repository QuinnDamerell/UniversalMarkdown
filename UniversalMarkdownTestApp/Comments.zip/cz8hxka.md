The municipalities are suffering from the same issues that everyone else is: lack of revenues, increasing costs for everything, and so on.  At that level, the costs to repair roads and other infrastructure balloons, along with every other municipal project on the docket. 

So when it comes down to it, many places, especially those like Flint, Baltimore, and others that suffer from urban blight, population flight, and poverty, are struggling with the conundrum of where to spend their resources. Do they fix the crumbling roads? Address the bridges? Invest in the schools that are falling apart? Improve policing and fire? Do things to attract more people to boost revenues?

There comes a point at which it's no longer a problem of checking off a list of things to keep fixed every year, and instead a case of the proverbial drowning homeowner trying to triage the worst things based on the complaints, and hoping something else doesn't fall apart. 

Cities don't have huge amounts of money to blow, states have to spread their money out across the state along with addressing state-wide necessities, and the feds are trying to handle the entire country. 

Sure, there's nepotism and graft, but overall, the cost to revamp, rebuild, and replace systems across the country, especially in places where it's really old and has had piecemeal upgrades and patches, is so high that there just really isn't enough money to do it all. 