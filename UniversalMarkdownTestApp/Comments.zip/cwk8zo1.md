Username: /u/darksingularity1

General Field: Biology/Neuroscience

Specific Field: Neuroscience

Research Area: Effects of Depression on Spatial Memory and Hippocampal anatomy.

Education: BS in Neuro; grad student.

Comments: [1](https://www.reddit.com/r/askscience/comments/1ngxhs/are_human_feet_any_more_thermosensitive_than/cciq1pz),
[2](https://www.reddit.com/r/askscience/comments/1mmuag/in_documentaries_about_the_human_brain_when_they/ccatquj)
, [3](https://www.reddit.com/r/askscience/comments/1mp5vr/is_there_any_measurable_difference_between/ccblgau)
, [4](https://www.reddit.com/r/askscience/comments/1n0psb/how_does_my_brain_come_up_with_people_i_have/ccedozp)
, [5](https://www.reddit.com/r/askscience/comments/1sff4x/if_gaba_is_an_inhibitory_neurotransmitter_ie/cdxgikl)
, [6](https://www.reddit.com/r/askscience/comments/1nmi94/how_does_the_brain_form_mental_images_and_why/cck37o7),
[7](https://www.reddit.com/r/askscience/comments/1neqgf/memory/cck55n5)
, [8](https://www.reddit.com/r/askscience/comments/1n6j93/why_cant_i_remember_a_definition_i_studied_but/cck58iy)
, [9](https://www.reddit.com/r/askscience/comments/25qdtq/why_do_mutations_occur_at_all_during_dna/chjtmaz)

Also, I have /r/science flair.