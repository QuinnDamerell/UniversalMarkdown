I also want to mention that, at least when/where I was in college 5+ years ago, labs didn't often double check the grades of the undergrads that were applying for jobs with them, if that's stopping you. 

I'm not advocating this tactic and I'm not proud of having done it but as an undergrad I did frequently lie about my grades whenever I was asked by a lab I was trying to get in to. 