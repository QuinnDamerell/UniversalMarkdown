Username: /u/rknoops

General field: Physics

Specific field: Particle Physics | Theoretical 

Particular areas of research: Supergravity theories and supersymmetry breaking mechanisms

Education: PhD student.

[1](https://www.reddit.com/r/askscience/comments/3upsds/where_is_the_warmest_place_in_the_known_universe/cxhxdbm) 
[2](https://www.reddit.com/r/geneva/comments/3qnt93/unexpected_24hr_stay_in_geneva_sunday_evenmonday/cwh74zj)