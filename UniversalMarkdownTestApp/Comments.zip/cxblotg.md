Username: /u/MegafaunaMamMel
General field: Earth and Planetary Sciences
Specific field: Paleontology
Particular areas of research including historical: Pleistocene mammal extinctions and paleoecology
Education: MS in geosciences, 6th year PhD in Biology
/u/StringOfLights