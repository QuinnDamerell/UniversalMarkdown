I'd just like to clarify for any non-chemists, AA is atomic absorption, and ICP-MS is inductively coupled plasma-mass spectrometry.

Chemists work with the coolest sounding instruments.