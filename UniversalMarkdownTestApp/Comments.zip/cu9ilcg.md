Username: /u/BurkeyAcademy

General field: Social Sciences

Specific field: Economics and Spatial Statistics

Particular areas of research including historical: Spatial Statistics, Location Theory, Microeconomics

Education: Ph.D. in Economic Theory, Professor for 15 years, Journal Editor

Note: Have flair in /r/science

Comments: [1](https://www.reddit.com/r/AskStatistics/comments/3dmdf9/question_about_notation_for_variance/ct6iir6), [2](https://www.reddit.com/r/statistics/comments/3c4j4s/gender_pay_gap_myth_or_real_what_about_eye_colour/css7x58), [3](https://www.reddit.com/r/probabilitytheory/comments/3bja6h/probabilities_of_raffle_drawings_picking_the_last/csmoj0d), [4](https://www.reddit.com/r/gis/comments/3ajdq2/how_do_i_determine_distance_and_bearing_from_gps/csdaj4p).