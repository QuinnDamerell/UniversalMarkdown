Username: /u/kagantx

General field: Physics

Specific field: Astrophysics

Particular areas of research including historical: Plasma astrophysics and magnetic reconnection

Education: Ph.D.

Comments: [1](https://www.reddit.com/r/askscience/comments/3yz9mk/hypothetically_can_period_8_have_a_further_sub/cyi6ejn) [2](https://www.reddit.com/r/askscience/comments/3yhruk/how_long_does_the_universe_have_left/cyh8dt5) [3](https://www.reddit.com/r/askscience/comments/40nwxl/if_gravity_works_by_warping_space_why_doesnt/cywmnf8) [4](https://www.reddit.com/r/askscience/comments/3zs0p7/what_makes_octaves_in_music_sound_similar/cyp7evx) [5](https://www.reddit.com/r/askscience/comments/4108d3/could_life_exist_in_the_moon_of_a_giant_gas/cyz1b3w) [6](https://www.reddit.com/r/askscience/comments/4234fq/does_special_relativity_preclude_multiple_time/cz7muqh)