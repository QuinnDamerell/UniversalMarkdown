The city council voted for this. The Mayor and the Emergency Manager Approved it. Water treatment was the issue.

Fucking seriously, what is wrong with everybody running up the food chain to find an (R) to blame.