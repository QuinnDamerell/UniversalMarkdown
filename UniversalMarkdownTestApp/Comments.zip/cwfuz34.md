/u/adamsolomon

I am in my final year of undergraduate education at a liberal arts college hoping to follow the same route, i.e. obtain a theoretical physics PhD. I'm majoring in physics and mathematics. I love physics and know that it would be an enjoyable career path to become a professor. But I have some reservations about starting a PhD right now. That is, I don't know if I currently have the excitement or motivation to complete a PhD. Perhaps I do, but am worried to find that the answer is "No". What sort of outlook or attitude should one have before going down this path?

Another standard question, what do you wish you had known before beginning a PhD?