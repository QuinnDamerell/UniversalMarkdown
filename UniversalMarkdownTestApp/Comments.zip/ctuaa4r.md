Username: /u/nonabeliangrape

General field: Physics

Specific field: Theoretical Particle Physics

Areas of research: Dark matter, Beyond the Standard Model (BSM)

Education: Physics PhD student

Comments: [1](https://www.reddit.com/r/askscience/comments/3fytij/how_can_we_tell_dark_matter_isnt_just_unseeble/cttrh4n), [2](https://www.reddit.com/r/askscience/comments/3g1roi/are_there_superconductors_for_other_forces_or/ctu49kv), [3](https://www.reddit.com/r/askscience/comments/3fyn9a/if_gravity_is_curvature_of_spacetime_would_an/ctu1wnr), [4](https://www.reddit.com/r/askscience/comments/ejtlk/how_do_we_know_the_second_law_of_thermodynamics/c18mbfh)

Edit: [5](https://www.reddit.com/r/askscience/comments/3nmuvy/what_would_happen_if_there_was_an_unbreakable/cvpj8kd)