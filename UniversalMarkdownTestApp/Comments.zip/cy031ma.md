Username: /u/UseYourThumb

General Field: Neuroscience

Specific Field: Electrophysiology

Area of expertise: Dopamine, Norepinephrine, synaptic plasticity, neural excitability, hippocampus, locus coeruleus.

Education: 3rd year graduate student

Comments: [1](https://www.reddit.com/r/neuroscience/comments/3wql8k/electrophysiology_help/cxzu6j4), [2](https://www.reddit.com/r/askscience/comments/3mqr4l/when_a_neurotransmitter_is_released_it_can_alter/cvibnyr), [3](https://www.reddit.com/r/askscience/comments/3mogq5/how_many_molesmolecules_of_a_given_monoamine/cvh8uuo), [4](https://www.reddit.com/r/askscience/comments/2zyqxj/when_i_fall_asleep_with_headphones_on_why_cant_i/cprr094), [5](https://www.reddit.com/r/askscience/comments/2yqycx/can_anyone_explain_to_me_how_5hta1_receptors_cell/cpcwfjs)