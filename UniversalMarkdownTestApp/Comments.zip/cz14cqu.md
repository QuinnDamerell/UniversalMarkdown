Hi there.
I've been meaning to get my doubt answered for couple of weeks now, but Google and Wikipedia (for the first time ever) have not been able to help me out.

I was wondering, when considering elements and their electronic configurations, is it possible to tell if an element is para/dia/ferro/ferri/anti ferro magnetic by just checking their configuration?

Thanks!