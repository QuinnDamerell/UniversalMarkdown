Username: /u/mabolle

General field: Biology

Specific field: Evolutionary ecology

Particular areas of research including historical: Local adaptation; insect life cycles

Education: PhD student.

Comments: [1](https://www.reddit.com/r/askscience/comments/322eop/how_did_fish_in_closed_lakesponds_get_there/cq7mzyk), [2](https://www.reddit.com/r/AskScienceDiscussion/comments/2dm3ud/how_is_blonde_hair_and_ginger_hair_inherited_and/cjqwpo2), [3](https://www.reddit.com/r/askscience/comments/2vodcy/wales_seals_or_penguins_still_need_to_go_to_the/coo18ay), [4](https://www.reddit.com/r/askscience/comments/305dzr/can_a_plant_pollinate_its_self/cpqltjd), [5](https://www.reddit.com/r/askscience/comments/2zpp7m/why_are_green_photosynthetic_pigments_more_common/cpnu5l4).