- Better grades would have helped.  I know, not the best answer, but they would've really helped in getting in.

- Hah, well firstly I moved to a different continent, to a city famous internationally for its nightlife, so I do a lot more interesting things these days! :) (The beer is a lot better, but also great concerts and museums etc.) Also I think the difference is you have a much more adult thing- college is fun because all your friends are together, but now I can have my own apartment and do things on my own terms.

- Stick to the page limits and actually answer all the questions on your homework.