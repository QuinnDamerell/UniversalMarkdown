Username: /u/_dissipator

General field: Physics

Specific field: Quantum theory

Particular areas of research (to name just a few): macroscopic quantum systems, measurement in quantum mechanics, quantum systems out of equilibrium. (In all cases, I do theoretical, rather than experimental, research.)

Education: M.Sc. in theoretical physics (completed). About to begin my Ph.D. after a short break.

Comments: [1] (https://www.reddit.com/r/explainlikeimfive/comments/22s42x/eli5quantum_entanglment/cgpvbr8) (in ELI5), [2](https://www.reddit.com/r/askscience/comments/291sqm/its_impossible_to_determine_a_particles_position/cigqbxn) (in askscience), [3](https://www.reddit.com/r/Futurology/comments/3fsnhh/heres_that_lexus_hoverboard_finally_in_action/cts7zw4) (in futorology), [4](https://www.reddit.com/r/askscience/comments/3kl086/quantumgravity_if_a_particle_has_a_probability/cuzn9fn) (in askscience).