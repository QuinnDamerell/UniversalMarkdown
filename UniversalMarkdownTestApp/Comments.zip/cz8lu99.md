16th largest metro area https://en.wikipedia.org/wiki/List_of_Metropolitan_Statistical_Areas

WE ARE RELEVANT I SWEAR FUCK YOU DENVER