I did my undergrad in economics, and then got my MBA. I would like to someday get a PhD in computer science, specifically machine learning. I'm already in my 30s and making enough money where taking 5 years to go back to school wouldn't make financial sense. 

Is there any way of getting my degree quicker? Would completing Georgia Tech's OMSCS be beneficial? 

What would getting my PhD entail? Are there classes, or mostly just research and publishing? If I'm getting papers published on my own could that count some way into the degree?