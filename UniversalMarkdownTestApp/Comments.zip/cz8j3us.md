Governor didn't do that.  Neither did the EM.  

They just make good scapegoats for Reddit.