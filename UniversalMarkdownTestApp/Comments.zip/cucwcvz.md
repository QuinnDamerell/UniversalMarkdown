Username: Grandmaofhurt

General field: Engineering

Specific field: Electrical Engineering

Research Area: Non-linear Optics and Electro-Optics

Education: Electronics Technician, Nuclear, U.S. Navy; B.S.E.E., Cum Laude, ODU; 2nd year Master's Student and Researcher, UTSA.

Have flair in /r/science 