What are some possible applications for the discoveries and advancements being done in physics, for example the recently discovered subatomic particles (I just know they apparently exist, I dont know anything else). Do you think there will be another thing as revolutionary as electricity used in the near future?

Is there any breakthrough you're particularly excited for?