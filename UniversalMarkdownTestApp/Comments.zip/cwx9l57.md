**Username**: lunamoon_girl

**General Field**: Neuroscience

**Specific field**: Alzheimer's disease and prion-like propagation

**Areas of interest**: Medicine (MD/PhD student), and tau protein misfolding and pathological spread in neurodegenerative disorders such as Alzheimer's disease.

**Education**: BA in molecular and cell biology (neuroscience emphasis), currently in an MD/PhD program at washington university in St. Louis studying Tau protein propagation.

**Comments**: [1](https://www.reddit.com/r/science/comments/388hcn/poor_sleep_linked_to_toxic_buildup_of_alzheimers/cruniu4) [2](https://www.reddit.com/r/science/comments/388hcn/poor_sleep_linked_to_toxic_buildup_of_alzheimers/crtvzlk) [3](https://www.reddit.com/r/science/comments/388hcn/poor_sleep_linked_to_toxic_buildup_of_alzheimers/crtumsq) [4](https://www.reddit.com/r/politics/comments/36600c/california_passes_sb_277_bill_forcing_all/crbmjfv) [5](https://www.reddit.com/r/AskReddit/comments/2tr0fd/reddit_what_are_you_afraid_of_other_redditors_why/co25cur) [6](https://www.reddit.com/r/science/comments/2brxu6/low_education_makes_the_brain_age_faster_mental/cj9160p) [7](https://www.reddit.com/r/science/comments/2brxu6/low_education_makes_the_brain_age_faster_mental/cj8jvt0)

**Currently have flair on r/Science**: "Grad Student|Med Student|Neuroscience|Alzheimer's"