Unsolicited advice: Thinking about grad school in **evolutionary and ecological** biology? Get a Master's degree. 

You will have more information about what graduate school is, more opportunities, and be better qualified for getting a PhD. You'll know who the players are and maybe you'll rule out a field or topic. You might publish or you may find out that you hate academics. All of this is useful. I think you have the most options with a Master's (more than undergrad and PhD). When you go down the road of a PhD, you start limiting yourself becoming overqualified. Also the [job market for PhDs sucks](http://www.ascb.org/where-will-a-biology-phd-take-you/).  

That said, the ones going into a PhD against sage advice are the ones who may have what it takes. I landed the golden unicorn of a job against all odds but I also wouldn't have really cared if I didn't because I got to play with turtles and salamanders for like 20 years. 

*edit: added words in bold to distinguish that diversity of biological fields have different takes on this*