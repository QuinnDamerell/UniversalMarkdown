40 bucks for a metals analysis is actually pretty cheap.  We analyze for methods by EPA method 6010B and it's usually around 80-120 per sample.  FYI lead may be the hot button metal right now, but LOTS of heavy metals wind up in your water.  Test for all the big ones if you want to be sure you're safe.

Edit: read the rate sheet wrong.