Username: /u/cryoprof


General field: Engineering


Specific Field: Bioengineering


Particular areas of research: Phase transformations | Cryobiology
