There's no quick fix to this aside from just handing every citizen 100K and saying "get out". 

Though that might be cheaper in the long run.