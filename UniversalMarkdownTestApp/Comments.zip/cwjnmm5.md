Username: /u/turtle_flu

General field: Biology

Specific field: Viral gene therapy

Particular areas of research including historical: Adeno-associated viral vectors (AAV), Lentivirus, Foamy virus (spumavirus), retinal and hematopoietic gene therapy.

Education: Ph.D. in progress - 3rd year - Medical and Molecular genetics 

Comments: [1](https://www.reddit.com/r/science/comments/36hq9i/potential_new_vaccine_blocks_every_strain_of_hiv/cre4ppc), [2](https://www.reddit.com/r/science/comments/36hq9i/potential_new_vaccine_blocks_every_strain_of_hiv/cre9mn6), 

Flaired in /r/science