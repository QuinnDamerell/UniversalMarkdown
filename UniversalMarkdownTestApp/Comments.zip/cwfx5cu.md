I know I'm not on the panel... but i'm a 5th year PhD student in Electrical Engineering studying physical human robot interaction (we are working on making robots better and safer!) focusing on powered prosthetic devices.  

I wouldn't mind helping where I can.  (Mods, do I need to verify anything?)  

Also, do the folks at /r/GradSchool know?