Hi /u/tariban,

I might have accidentally stumbled on the perfect person to ask a question that I've been thinking about for a few days now.

I have thousands upon thousands of questions that I wish to categorize and I'm trying to find the best way to do it. I'm looking at choosing between strict categories, tags, a hybrid method of some sorts or maybe something completely different. Putting the questions in categories (or tagging them) is less of an issue as coming up with a way that can then be reliably and intuitively navigated by anyone.

I'm wondering if you can point me to either books on the subject or academic studies or really anything that could help me make an informed decision in this situation? 

Cheers.