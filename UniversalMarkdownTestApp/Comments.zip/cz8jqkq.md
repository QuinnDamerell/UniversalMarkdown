Why isn't *The Guardian* article the one linked? Is there a benefit to the *Gizmodo* one?

I wonder if it's a good idea to recommend (but, in my opinion, not require), at a subreddit level, that the original article be the one posted.

http://www.theguardian.com/environment/2016/jan/22/water-lead-content-tests-us-authorities-distorting-flint-crisis