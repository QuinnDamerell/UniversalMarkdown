the US Army....they'll kill you...on christmas night...while crossing a half frozen river in zero temperatures.

i'd expect nothing less for such a prestigious monument. 