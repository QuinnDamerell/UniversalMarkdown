Username: [u/shamdalar](http://reddit.com/u/shamdalar)

General field: Mathematics

Specific field: Probability Theory | Complex Analysis

Particular areas of research: Conformal representations of random trees and their scaling limits.

Education: Completed PhD

Comments: [1](https://www.reddit.com/r/askscience/comments/2ex17m/if_i_had_100_atoms_of_a_substance_with_a_10day/ck3t8cp), [2](https://www.reddit.com/r/askscience/comments/307dw7/is_there_a_way_to_tell_which_number_is_bigger/cppuzef), [3](https://www.reddit.com/r/askscience/comments/2fyr1r/how_can_we_be_sure_what_functions_do_as_they_go/cke1wmd), [4] (https://www.reddit.com/r/askscience/comments/1usja3/can_a_4dimensional_world_be_depicted_in_a/celi5gb), [5](https://www.reddit.com/r/askscience/comments/1x2qsv/ask_anything_wednesday_engineering_mathematics/cf7rzpr)