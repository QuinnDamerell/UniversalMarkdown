Username: AugustusFink-nottle

General Field: Physics

Specific Field: Biophysics, Statistical mechanics

Research Area: DNA-protein interactions, Retroviruses

Education: PhD and PostDoc

Comments: [1](https://www.reddit.com/r/askscience/comments/3phlq7/is_earths_atmosphere_unique_can_this_be_use_to/cw6f730), [2](https://www.reddit.com/r/askscience/comments/3oyhgp/what_prevents_a_force_being_used_as_energy/cw1p186), [3](https://www.reddit.com/r/askscience/comments/3oe17g/can_stimulated_emission_be_explained_by/cvwo3kh), [4](https://www.reddit.com/r/askscience/comments/3obvwv/how_does_a_moving_charge_produce_a_magnetic_field/cvvvqkv), [5](https://www.reddit.com/r/askscience/comments/3o31qz/how_do_cells_read_dna/cvtlr2g)