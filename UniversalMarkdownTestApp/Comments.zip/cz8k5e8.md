/u/sick_as_fuckkk's doctor:

["do you want the all-leaden news, or the all-leaden news?"](http://i.imgur.com/BHpq518.gif)